# LAN protocol (multiplayer/lan_manager.gd, autoload `Net`)

Transport: Godot `ENetMultiplayerPeer` (UDP) - host listens on **45679**, up to 4 players.
Discovery: host sends a JSON beacon to `255.255.255.255`, each local `a.b.c.255` and `127.0.0.1`,
UDP port **45678**, once per second:
`{"g":"FBU","v":1,"room":"...","port":45679,"n":2,"max":4,"phase":"lobby"}`.
Clients bind 45678 while on the "Join" screen and drop rooms not heard from for 4.5 s.

Phases: `idle -> lobby -> playing -> results -> lobby ...`

| RPC | Direction | Mode | Purpose |
|---|---|---|---|
| `_register(token,name,skin,proto)` | client -> host | reliable | claim a seat (token identifies the player across reconnects) |
| `_accepted` / `_rejected` | host -> client | reliable | result of registration (room full, match running, version) |
| `_sync_players(dict)` | host -> all | reliable | roster, ready flags, connection flags |
| `_req_ready`, `_req_leave` | client -> host | reliable | ready toggle / intentional leave |
| `_begin_match(seed, players)` | host -> all (+local) | reliable | start loading the game scene with a shared pipe seed |
| `_req_loaded` -> `_go` | client -> host -> all | reliable | host starts the shared 3-2-1 countdown when everyone loaded (8 s timeout) |
| `_net_state(token,y,vy,score,alive)` | any -> all | unreliable ordered, 20 Hz | live bird sync (ghost interpolation + prediction) |
| `_req_dead` -> `_player_died` | client -> host -> all | reliable | death + final score |
| `_match_over(results)` | host -> all | reliable | sorted results when nobody is alive |
| `_return_lobby` | host -> all | reliable | everyone back to the lobby, ready flags reset |
| `_host_closing` | host -> clients | reliable | skip reconnect attempts when the host leaves on purpose |

Fairness: pipes are generated from the shared seed in index order and positions depend only on
elapsed play time (constant speed in multiplayer), so every device sees identical pipes.
Each device simulates its own bird locally (no input lag); only state is exchanged.

Reconnection: on connection loss a client retries the host up to 10 times (4 s each) and re-sends
`_register` with its token. The host keeps the seat for 20 s (a dead/forfeited bird afterwards).
A running game keeps simulating locally during the outage and re-sends its death on reconnect.
