extends Node
## LAN multiplayer (autoload "Net").
##  * Host/Client over ENet (UDP) on the local Wi-Fi network - no internet, no server.
##  * Automatic room discovery through UDP broadcast on DISCOVERY_PORT.
##  * Ready system, synchronized match start (everyone loads, host says "go").
##  * Live bird state sync (unreliable, ~20 Hz) + reliable death / results events.
##  * Reconnection: clients retry the host automatically and re-claim their seat via a token.
## See multiplayer/README.md for the protocol description.

signal players_changed
signal rooms_changed
signal join_failed(reason: String)
signal joined
signal connection_lost
signal reconnecting(attempt: int, max_attempts: int)
signal reconnected
signal host_lost
signal match_started(rng_seed: int)
signal go
signal remote_state(token: String, y: float, vy: float, score: int, alive: bool)
signal player_died(token: String, score: int)
signal match_over(results: Array)
signal returned_to_lobby

const DISCOVERY_PORT: int = 45678
const GAME_PORT: int = 45679
const MAX_PLAYERS: int = 4
const PROTOCOL: int = 1
const GRACE_SECONDS: float = 20.0
const MAX_RECONNECT: int = 10
const LOAD_TIMEOUT: float = 8.0
const STATE_HZ: float = 20.0

var active: bool = false
var is_host: bool = false
var phase: String = "idle"          # idle | lobby | playing | results
var my_token: String = ""
var my_name: String = "Player"
var players: Dictionary = {}        # token -> {name, skin, ready, connected, peer, alive, score}
var match_seed: int = 0
var room_name: String = ""
var rooms: Dictionary = {}          # ip -> {room, port, n, max, phase, seen}
var host_ip: String = ""
var host_port: int = GAME_PORT
var go_received: bool = false

var _bc_sock: PacketPeerUDP = null
var _bc_timer: float = 0.0
var _listen: PacketPeerUDP = null
var _leaving: bool = false
var _reconnecting: bool = false
var _attempt_failed: bool = false
var _host_quit: bool = false
var _loaded: Dictionary = {}
var _went: bool = false
var _state_timer: float = 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	my_token = "%08x%08x" % [randi(), randi()]
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)

# ---------------------------------------------------------------- helpers
static func is_private_ip(ip: String) -> bool:
	var p: PackedStringArray = ip.strip_edges().split(".")
	if p.size() != 4:
		return false
	for part in p:
		if not part.is_valid_int() or int(part) < 0 or int(part) > 255:
			return false
	var a: int = int(p[0])
	var b: int = int(p[1])
	return a == 10 or a == 127 or (a == 192 and b == 168) or (a == 172 and b >= 16 and b <= 31) or (a == 169 and b == 254)

func local_ips() -> Array:
	var out: Array = []
	for ip in IP.get_local_addresses():
		if ip.count(".") == 3 and is_private_ip(ip) and not ip.begins_with("127."):
			out.append(ip)
	return out

func player_count() -> int:
	var n: int = 0
	for t in players:
		if players[t]["connected"]:
			n += 1
	return n

func _new_player(pname: String, skin: int, peer: int) -> Dictionary:
	return {"name": pname, "skin": skin, "ready": false, "connected": true, "peer": peer, "alive": true, "score": 0}

func _token_of(peer: int) -> String:
	for t in players:
		if int(players[t]["peer"]) == peer:
			return t
	return ""

# ---------------------------------------------------------------- hosting
func host_room(pname: String, room: String) -> int:
	_close_peer()
	var peer: ENetMultiplayerPeer = ENetMultiplayerPeer.new()
	var err: int = peer.create_server(GAME_PORT, MAX_PLAYERS - 1)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	_leaving = false
	active = true
	is_host = true
	phase = "lobby"
	my_name = pname
	room_name = room
	players.clear()
	players[my_token] = _new_player(pname, Save.skin, 1)
	_start_broadcast()
	players_changed.emit()
	return OK

func _start_broadcast() -> void:
	_stop_broadcast()
	_bc_sock = PacketPeerUDP.new()
	_bc_sock.set_broadcast_enabled(true)
	_bc_timer = 1.0

func _stop_broadcast() -> void:
	if _bc_sock != null:
		_bc_sock.close()
		_bc_sock = null

func _broadcast_targets() -> Array:
	var t: Array = ["255.255.255.255", "127.0.0.1"]
	for ip in local_ips():
		var p: PackedStringArray = str(ip).split(".")
		t.append("%s.%s.%s.255" % [p[0], p[1], p[2]])
	return t

func _send_beacon() -> void:
	if _bc_sock == null:
		return
	var msg: Dictionary = {"g": "FBU", "v": PROTOCOL, "room": room_name, "port": GAME_PORT,
		"n": player_count(), "max": MAX_PLAYERS, "phase": phase}
	var bytes: PackedByteArray = JSON.stringify(msg).to_utf8_buffer()
	for dest in _broadcast_targets():
		_bc_sock.set_dest_address(dest, DISCOVERY_PORT)
		_bc_sock.put_packet(bytes)

# ---------------------------------------------------------------- discovery (client side)
func start_discovery() -> void:
	stop_discovery()
	_listen = PacketPeerUDP.new()
	var err: int = _listen.bind(DISCOVERY_PORT, "*")
	if err != OK:
		push_warning("LAN discovery could not bind UDP %d (error %d). Manual IP still works." % [DISCOVERY_PORT, err])
		_listen = null
	rooms.clear()
	rooms_changed.emit()

func stop_discovery() -> void:
	if _listen != null:
		_listen.close()
		_listen = null

func _poll_discovery() -> void:
	var changed: bool = false
	while _listen.get_available_packet_count() > 0:
		var pkt: PackedByteArray = _listen.get_packet()
		var ip: String = _listen.get_packet_ip()
		var d: Variant = JSON.parse_string(pkt.get_string_from_utf8())
		if d is Dictionary and d.get("g", "") == "FBU" and int(d.get("v", 0)) == PROTOCOL:
			var info: Dictionary = {"room": str(d.get("room", "Room")), "port": int(d.get("port", GAME_PORT)),
				"n": int(d.get("n", 1)), "max": int(d.get("max", MAX_PLAYERS)), "phase": str(d.get("phase", "lobby")),
				"seen": Time.get_ticks_msec()}
			if not rooms.has(ip) or rooms[ip]["n"] != info["n"] or rooms[ip]["phase"] != info["phase"] or rooms[ip]["room"] != info["room"]:
				changed = true
			rooms[ip] = info
	var now: int = Time.get_ticks_msec()
	for ip in rooms.keys():
		if now - int(rooms[ip]["seen"]) > 4500:
			rooms.erase(ip)
			changed = true
	if changed:
		rooms_changed.emit()

# ---------------------------------------------------------------- joining
func join_room(ip: String, port: int, pname: String) -> int:
	ip = ip.strip_edges()
	if not is_private_ip(ip):
		join_failed.emit("Only local network (Wi-Fi) addresses are allowed.")
		return ERR_INVALID_PARAMETER
	_close_peer()
	var peer: ENetMultiplayerPeer = ENetMultiplayerPeer.new()
	var err: int = peer.create_client(ip, port)
	if err != OK:
		join_failed.emit("Could not start connection (error %d)." % err)
		return err
	multiplayer.multiplayer_peer = peer
	_leaving = false
	_host_quit = false
	_reconnecting = false
	active = true
	is_host = false
	phase = "idle"
	host_ip = ip
	host_port = port
	my_name = pname
	Save.data["last_ip"] = ip
	return OK

func _on_connected_to_server() -> void:
	rpc_id(1, "_register", my_token, my_name, Save.skin, PROTOCOL)

func _on_connection_failed() -> void:
	if _reconnecting:
		_attempt_failed = true
		return
	_close_peer()
	active = false
	join_failed.emit("Could not reach the host. Check the IP and that both devices are on the same Wi-Fi.")

func _on_server_disconnected() -> void:
	if _leaving or is_host:
		return
	if _host_quit or phase == "idle":
		_close_peer()
		active = false
		phase = "idle"
		host_lost.emit()
		return
	connection_lost.emit()
	if not _reconnecting:
		_reconnecting = true
		_reconnect_loop()

func _reconnect_loop() -> void:
	for i in range(1, MAX_RECONNECT + 1):
		if not _reconnecting or _leaving:
			return
		reconnecting.emit(i, MAX_RECONNECT)
		_attempt_failed = false
		var peer: ENetMultiplayerPeer = ENetMultiplayerPeer.new()
		if peer.create_client(host_ip, host_port) == OK:
			multiplayer.multiplayer_peer = peer
		var waited: float = 0.0
		while waited < 4.0 and _reconnecting and not _leaving and not _attempt_failed:
			await get_tree().create_timer(0.25).timeout
			waited += 0.25
		if not _reconnecting:
			return  # re-registered successfully (see _accepted)
		_close_peer()
	if _reconnecting and not _leaving:
		_reconnecting = false
		active = false
		phase = "idle"
		host_lost.emit()

# ---------------------------------------------------------------- leaving
func leave() -> void:
	_leaving = true
	_reconnecting = false
	if active and multiplayer.multiplayer_peer != null:
		if is_host:
			rpc("_host_closing")
			await get_tree().create_timer(0.25).timeout
		elif phase != "idle":
			rpc_id(1, "_req_leave")
			await get_tree().create_timer(0.15).timeout
	_stop_broadcast()
	_close_peer()
	active = false
	is_host = false
	phase = "idle"
	players.clear()

func _close_peer() -> void:
	var p: MultiplayerPeer = multiplayer.multiplayer_peer
	if p != null and p is ENetMultiplayerPeer:
		p.close()
	multiplayer.multiplayer_peer = null

# ---------------------------------------------------------------- peers (host side events)
func _on_peer_connected(_id: int) -> void:
	pass

func _on_peer_disconnected(id: int) -> void:
	if not is_host:
		return
	var tok: String = _token_of(id)
	if tok == "" or tok == my_token:
		return
	if phase == "lobby":
		players.erase(tok)
		_broadcast_players()
		return
	players[tok]["connected"] = false
	_broadcast_players()
	_grace(tok)

func _grace(tok: String) -> void:
	await get_tree().create_timer(GRACE_SECONDS).timeout
	if not is_host or not players.has(tok):
		return
	if not players[tok]["connected"]:
		players[tok]["alive"] = false
		_broadcast_players()
		_check_match_end()

# ---------------------------------------------------------------- registration / lobby
@rpc("any_peer", "call_remote", "reliable")
func _register(token: String, pname: String, skin: int, proto: int) -> void:
	if not is_host:
		return
	var sender: int = multiplayer.get_remote_sender_id()
	if proto != PROTOCOL:
		_reject(sender, "Game version mismatch.")
		return
	if players.has(token):
		players[token]["peer"] = sender
		players[token]["connected"] = true
	else:
		if phase != "lobby":
			_reject(sender, "A match is already in progress.")
			return
		if players.size() >= MAX_PLAYERS:
			_reject(sender, "Room is full.")
			return
		players[token] = _new_player(pname.substr(0, 12), skin, sender)
	rpc_id(sender, "_accepted", phase, room_name)
	_broadcast_players()
	if phase == "playing":
		rpc_id(sender, "_resume_info", match_seed)

func _reject(peer_id: int, reason: String) -> void:
	rpc_id(peer_id, "_rejected", reason)
	await get_tree().create_timer(0.3).timeout
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer.disconnect_peer(peer_id)

@rpc("authority", "call_remote", "reliable")
func _rejected(reason: String) -> void:
	_leaving = true
	_close_peer()
	active = false
	phase = "idle"
	join_failed.emit(reason)

@rpc("authority", "call_remote", "reliable")
func _accepted(host_phase: String, room: String) -> void:
	phase = host_phase
	room_name = room
	if _reconnecting:
		_reconnecting = false
		reconnected.emit()
	else:
		joined.emit()

@rpc("authority", "call_remote", "reliable")
func _resume_info(rng_seed: int) -> void:
	match_seed = rng_seed

@rpc("authority", "call_remote", "reliable")
func _host_closing() -> void:
	_host_quit = true

func _broadcast_players() -> void:
	if not is_host:
		return
	rpc("_sync_players", players)
	players_changed.emit()

@rpc("authority", "call_remote", "reliable")
func _sync_players(data: Dictionary) -> void:
	players = data
	players_changed.emit()

func set_ready(r: bool) -> void:
	if is_host:
		_host_set_ready(my_token, r)
	else:
		rpc_id(1, "_req_ready", r)

@rpc("any_peer", "call_remote", "reliable")
func _req_ready(r: bool) -> void:
	if not is_host:
		return
	var tok: String = _token_of(multiplayer.get_remote_sender_id())
	if tok != "":
		_host_set_ready(tok, r)

func _host_set_ready(tok: String, r: bool) -> void:
	if players.has(tok) and phase == "lobby":
		players[tok]["ready"] = r
		_broadcast_players()

@rpc("any_peer", "call_remote", "reliable")
func _req_leave() -> void:
	if not is_host:
		return
	var tok: String = _token_of(multiplayer.get_remote_sender_id())
	if tok == "" or tok == my_token:
		return
	if phase == "lobby":
		players.erase(tok)
	else:
		players[tok]["connected"] = false
		players[tok]["alive"] = false
	_broadcast_players()
	_check_match_end()

func can_start() -> bool:
	if not is_host or phase != "lobby":
		return false
	if player_count() < 2:
		return false
	for t in players:
		if players[t]["connected"] and not players[t]["ready"]:
			return false
	return true

func is_ready(tok: String) -> bool:
	return players.has(tok) and bool(players[tok]["ready"])

# ---------------------------------------------------------------- match flow
func start_match() -> void:
	if not can_start():
		return
	for t in players:
		players[t]["alive"] = players[t]["connected"]
		players[t]["score"] = 0
	rpc("_begin_match", randi(), players)

@rpc("authority", "call_local", "reliable")
func _begin_match(rng_seed: int, pl: Dictionary) -> void:
	players = pl
	match_seed = rng_seed
	phase = "playing"
	go_received = false
	_went = false
	_loaded.clear()
	match_started.emit(rng_seed)
	if is_host:
		_go_timeout()

func _go_timeout() -> void:
	await get_tree().create_timer(LOAD_TIMEOUT).timeout
	if is_host and phase == "playing":
		_host_go()

## Every peer calls this once its game scene is ready.
func report_loaded() -> void:
	if not active:
		return
	if is_host:
		_mark_loaded(my_token)
	else:
		rpc_id(1, "_req_loaded")

@rpc("any_peer", "call_remote", "reliable")
func _req_loaded() -> void:
	if not is_host:
		return
	var tok: String = _token_of(multiplayer.get_remote_sender_id())
	if tok != "":
		_mark_loaded(tok)

func _mark_loaded(tok: String) -> void:
	_loaded[tok] = true
	for t in players:
		if players[t]["connected"] and not _loaded.has(t):
			return
	_host_go()

func _host_go() -> void:
	if _went:
		return
	_went = true
	rpc("_go")

@rpc("authority", "call_local", "reliable")
func _go() -> void:
	go_received = true
	go.emit()

func send_state(y: float, vy: float, score: int, alive: bool) -> void:
	if not active or phase != "playing" or multiplayer.multiplayer_peer == null:
		return
	if multiplayer.multiplayer_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		return
	rpc("_net_state", my_token, y, vy, score, alive)

@rpc("any_peer", "call_remote", "unreliable_ordered")
func _net_state(tok: String, y: float, vy: float, score: int, alive: bool) -> void:
	if players.has(tok):
		players[tok]["score"] = score
	remote_state.emit(tok, y, vy, score, alive)

func send_dead(score: int) -> void:
	if not active:
		return
	if is_host:
		_host_player_dead(my_token, score)
	elif multiplayer.multiplayer_peer != null and multiplayer.multiplayer_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED:
		rpc_id(1, "_req_dead", score)

@rpc("any_peer", "call_remote", "reliable")
func _req_dead(score: int) -> void:
	if not is_host:
		return
	var tok: String = _token_of(multiplayer.get_remote_sender_id())
	if tok != "":
		_host_player_dead(tok, score)

func _host_player_dead(tok: String, score: int) -> void:
	if not players.has(tok) or phase != "playing":
		return
	players[tok]["alive"] = false
	players[tok]["score"] = score
	rpc("_player_died", tok, score)
	_check_match_end()

@rpc("authority", "call_local", "reliable")
func _player_died(tok: String, score: int) -> void:
	if players.has(tok):
		players[tok]["alive"] = false
		players[tok]["score"] = score
	player_died.emit(tok, score)

func _check_match_end() -> void:
	if not is_host or phase != "playing":
		return
	for t in players:
		if players[t]["alive"]:
			return
	var list: Array = []
	for t in players:
		list.append({"token": t, "name": players[t]["name"], "score": int(players[t]["score"]), "skin": int(players[t]["skin"])})
	list.sort_custom(func(a, b): return a["score"] > b["score"])
	rpc("_match_over", list)

@rpc("authority", "call_local", "reliable")
func _match_over(results: Array) -> void:
	phase = "results"
	match_over.emit(results)

func return_to_lobby() -> void:
	if not is_host:
		return
	for t in players.keys():
		if not players[t]["connected"]:
			players.erase(t)
		else:
			players[t]["ready"] = false
			players[t]["alive"] = true
			players[t]["score"] = 0
	rpc("_return_lobby", players)

@rpc("authority", "call_local", "reliable")
func _return_lobby(pl: Dictionary) -> void:
	players = pl
	phase = "lobby"
	returned_to_lobby.emit()
	players_changed.emit()

# ---------------------------------------------------------------- tick
func _process(delta: float) -> void:
	if _bc_sock != null and is_host:
		_bc_timer += delta
		if _bc_timer >= 1.0:
			_bc_timer = 0.0
			_send_beacon()
	if _listen != null:
		_poll_discovery()
