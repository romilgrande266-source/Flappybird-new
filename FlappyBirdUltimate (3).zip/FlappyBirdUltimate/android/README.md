# Android notes

* Export presets (`export_presets.cfg`): `Android arm32` -> `armeabi-v7a` only, `Android arm64` -> `arm64-v8a` only.
* Prebuilt export templates are used (`gradle_build/use_gradle_build=false`), no Android build template needed.
* Permissions: `INTERNET` (needed by Android for any socket, used for LAN only), `ACCESS_NETWORK_STATE`,
  `ACCESS_WIFI_STATE`, `CHANGE_WIFI_MULTICAST_STATE`, `VIBRATE`.
* Orientation: sensor (portrait + landscape). Immersive fullscreen is on.
* Texture compression: ETC2/ASTC import is enabled in `project.godot` (required by Godot's Android export).
* Debug signing: `tools/ci_setup.sh` creates `~/.android/debug.keystore` (password `android`, alias `androiddebugkey`).
* Release signing: export `GODOT_ANDROID_KEYSTORE_RELEASE_PATH`, `GODOT_ANDROID_KEYSTORE_RELEASE_USER`,
  `GODOT_ANDROID_KEYSTORE_RELEASE_PASSWORD`, then `EXPORT_MODE=release bash tools/build_apks.sh`.
