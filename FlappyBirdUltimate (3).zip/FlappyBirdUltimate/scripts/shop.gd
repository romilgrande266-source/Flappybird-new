extends Control

const UI = preload("res://scripts/ui.gd")
const Assets = preload("res://scripts/assets.gd")

var box: VBoxContainer
var _t: float = 0.0
var _previews: Array = []

func _ready() -> void:
	box = UI.build_screen(self)
	_build()

func _process(delta: float) -> void:
	_t += delta
	for i in range(_previews.size()):
		var tr: TextureRect = _previews[i]
		tr.texture = Assets.bird(i, int(_t * 8.0 + i) % 3)

func _build() -> void:
	UI.clear(box)
	_previews.clear()
	box.add_theme_constant_override("separation", 12)
	box.add_child(UI.label("BIRD SHOP", 38, Color(1.0, 0.86, 0.2), 9))
	box.add_child(UI.coin_bar())
	var grid: GridContainer = GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	box.add_child(grid)
	for i in range(Save.SKIN_NAMES.size()):
		grid.add_child(_card(i))
	box.add_child(UI.spacer(6))
	var back: Button = UI.button("BACK", "ButtonRed", Vector2(200, 56))
	back.pressed.connect(func(): Transition.go("res://scenes/main_menu.tscn"))
	box.add_child(back)

func _card(i: int) -> PanelContainer:
	var pc: PanelContainer = PanelContainer.new()
	var vb: VBoxContainer = VBoxContainer.new()
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_theme_constant_override("separation", 6)
	pc.add_child(vb)
	var tr: TextureRect = TextureRect.new()
	tr.texture = Assets.bird(i, 1)
	tr.custom_minimum_size = Vector2(84, 62)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	vb.add_child(tr)
	_previews.append(tr)
	vb.add_child(UI.label(Save.SKIN_NAMES[i], 18, Color.WHITE, 3))
	var owned: bool = Save.is_unlocked(i)
	var equipped: bool = Save.skin == i
	var txt: String = "EQUIPPED" if equipped else ("SELECT" if owned else "BUY %d" % Save.SKIN_PRICES[i])
	var variant: String = "ButtonGreen" if equipped else ("Button" if owned else "ButtonYellow")
	var b: Button = UI.button(txt, variant, Vector2(92, 46))
	b.add_theme_font_size_override("font_size", 17)
	b.disabled = (not owned) and Save.coins < Save.SKIN_PRICES[i]
	var idx: int = i
	b.pressed.connect(func(): _on_card(idx))
	vb.add_child(b)
	return pc

func _on_card(i: int) -> void:
	if not Save.is_unlocked(i):
		if not Save.buy_skin(i):
			return
		Audio.play("coin")
	Save.skin = i
	Save.save()
	_build()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		Transition.go("res://scenes/main_menu.tscn")
