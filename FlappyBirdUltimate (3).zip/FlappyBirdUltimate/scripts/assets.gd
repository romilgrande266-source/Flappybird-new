extends RefCounted
## Texture loader with cache. Searches sprites/, backgrounds/ and animations/.

static var _cache: Dictionary = {}

static func tex(tex_name: String) -> Texture2D:
	if _cache.has(tex_name):
		return _cache[tex_name]
	var t: Texture2D = null
	for dir in ["sprites", "animations", "backgrounds"]:
		var p: String = "res://assets/%s/%s.png" % [dir, tex_name]
		if ResourceLoader.exists(p):
			t = load(p)
			break
	if t == null:
		push_warning("Missing texture: " + tex_name)
		var img: Image = Image.create(8, 8, false, Image.FORMAT_RGBA8)
		img.fill(Color.MAGENTA)
		t = ImageTexture.create_from_image(img)
	_cache[tex_name] = t
	return t

static func bird(skin: int, frame: int) -> Texture2D:
	return tex("bird_%d_%d" % [skin, frame])
