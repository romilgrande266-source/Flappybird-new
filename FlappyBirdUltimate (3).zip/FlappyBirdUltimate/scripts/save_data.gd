extends Node
## Persistent save data, settings and the run-time mode selection.

signal coins_changed

const SAVE_PATH: String = "user://flappy_save.json"
const DEFAULTS_PATH: String = "res://settings/default_settings.json"
const SKIN_NAMES: Array = ["Sunny", "Ruby", "Sky", "Mint", "Violet", "Golden"]
const SKIN_PRICES: Array = [0, 40, 40, 80, 80, 200]
const MODES: Array = ["classic", "endless", "challenge", "local2p", "lan", "practice"]

const CHALLENGE_LEVELS: Array = [
	{"title": "First Flight", "target": 5, "speed": 150.0, "gap": 225.0, "move": 0.0, "night": false},
	{"title": "Warm Up", "target": 8, "speed": 160.0, "gap": 210.0, "move": 0.0, "night": false},
	{"title": "Wobbly Pipes", "target": 10, "speed": 170.0, "gap": 200.0, "move": 14.0, "night": false},
	{"title": "Night Shift", "target": 12, "speed": 175.0, "gap": 190.0, "move": 0.0, "night": true},
	{"title": "Swing Time", "target": 15, "speed": 185.0, "gap": 185.0, "move": 28.0, "night": false},
	{"title": "Speed Run", "target": 15, "speed": 200.0, "gap": 175.0, "move": 0.0, "night": true},
	{"title": "Moonlight Dance", "target": 20, "speed": 190.0, "gap": 175.0, "move": 38.0, "night": true},
	{"title": "Pipe Storm", "target": 20, "speed": 205.0, "gap": 165.0, "move": 44.0, "night": false},
	{"title": "Midnight Rush", "target": 25, "speed": 215.0, "gap": 160.0, "move": 48.0, "night": true},
	{"title": "Ultimate Flight", "target": 30, "speed": 225.0, "gap": 155.0, "move": 56.0, "night": true},
]

var data: Dictionary = {
	"best": {"classic": 0, "endless": 0, "local2p": 0, "lan": 0},
	"coins": 0,
	"skin": 0,
	"unlocked": [0],
	"challenge_done": 0,
	"sfx": 0.8,
	"music": 0.5,
	"vibrate": true,
	"bg": 0,
	"low_quality": false,
	"show_fps": false,
	"fullscreen": false,
	"name": "Player",
	"last_ip": "",
	"games": 0,
}

# Selected before switching to the game scene.
var current_mode: String = "classic"
var current_level: int = 0

var coins: int:
	get: return int(data["coins"])
	set(v):
		data["coins"] = maxi(0, v)
		coins_changed.emit()
var skin: int:
	get: return int(data["skin"])
	set(v): data["skin"] = v
var sfx_volume: float:
	get: return float(data["sfx"])
	set(v): data["sfx"] = clampf(v, 0.0, 1.0)
var music_volume: float:
	get: return float(data["music"])
	set(v): data["music"] = clampf(v, 0.0, 1.0)
var vibrate: bool:
	get: return bool(data["vibrate"])
	set(v): data["vibrate"] = v
var bg_mode: int:
	get: return int(data["bg"])
	set(v): data["bg"] = v
var low_quality: bool:
	get: return bool(data["low_quality"])
	set(v): data["low_quality"] = v
var show_fps: bool:
	get: return bool(data["show_fps"])
	set(v): data["show_fps"] = v
var player_name: String:
	get: return str(data["name"])
	set(v): data["name"] = v.substr(0, 12)

func _ready() -> void:
	Engine.max_fps = 60
	# Low-end device heuristic (only applied when no save file exists yet).
	data["low_quality"] = OS.has_feature("mobile") and OS.get_processor_count() <= 4
	_merge(_read_json(DEFAULTS_PATH))
	_merge(_read_json(SAVE_PATH))
	data["name"] = str(data["name"]).substr(0, 12)
	apply_window()

func _read_json(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var f: FileAccess = FileAccess.open(path, FileAccess.READ)
	if f == null:
		return {}
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	if parsed is Dictionary:
		return parsed
	return {}

func _merge(src: Dictionary) -> void:
	for k in src:
		if k == "best" and src[k] is Dictionary:
			for m in src[k]:
				data["best"][m] = int(src[k][m])
		elif k == "unlocked" and src[k] is Array:
			var u: Array = []
			for v in src[k]:
				u.append(int(v))
			if not u.has(0):
				u.append(0)
			data["unlocked"] = u
		elif data.has(k):
			data[k] = src[k]

func save() -> void:
	var f: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(data))

func apply_window() -> void:
	if OS.has_feature("pc"):
		var fs: bool = bool(data["fullscreen"])
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if fs else DisplayServer.WINDOW_MODE_WINDOWED)

func best(mode: String) -> int:
	return int(data["best"].get(mode, 0))

## Returns true when the score is a new personal best.
func record_score(mode: String, score: int) -> bool:
	data["games"] = int(data["games"]) + 1
	var is_best: bool = false
	if data["best"].has(mode) and score > int(data["best"][mode]):
		data["best"][mode] = score
		is_best = true
	save()
	return is_best

func add_coins(n: int) -> void:
	coins = coins + n
	save()

func is_unlocked(i: int) -> bool:
	return data["unlocked"].has(i)

func buy_skin(i: int) -> bool:
	if is_unlocked(i):
		return true
	var price: int = SKIN_PRICES[i]
	if coins < price:
		return false
	coins = coins - price
	data["unlocked"].append(i)
	save()
	return true

func medal_for(score: int) -> int:
	if score >= 50: return 4
	if score >= 30: return 3
	if score >= 20: return 2
	if score >= 10: return 1
	return 0

func medal_bonus(medal: int) -> int:
	return [0, 2, 5, 10, 20][medal]

func medal_name(medal: int) -> String:
	return ["", "bronze", "silver", "gold", "platinum"][medal]

func reset_progress() -> void:
	var keep_name: String = player_name
	data["best"] = {"classic": 0, "endless": 0, "local2p": 0, "lan": 0}
	data["coins"] = 0
	data["skin"] = 0
	data["unlocked"] = [0]
	data["challenge_done"] = 0
	data["games"] = 0
	data["name"] = keep_name
	save()
	coins_changed.emit()
