extends Control

const UI = preload("res://scripts/ui.gd")

var box: VBoxContainer
var _reset_armed: bool = false

func _ready() -> void:
	box = UI.build_screen(self)
	_build()

func _toggle(label_text: String, getter: Callable, setter: Callable) -> Button:
	var b: Button = UI.button("", "Button", Vector2(300, 52))
	b.add_theme_font_size_override("font_size", 22)
	var refresh: Callable = func(): b.text = "%s: %s" % [label_text, "ON" if getter.call() else "OFF"]
	refresh.call()
	b.pressed.connect(func():
		setter.call(not getter.call())
		Save.save()
		refresh.call())
	return b

func _slider(title: String, value: float, on_change: Callable) -> VBoxContainer:
	var vb: VBoxContainer = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	vb.add_child(UI.label(title, 20, Color.WHITE, 4))
	var s: HSlider = HSlider.new()
	s.min_value = 0.0
	s.max_value = 1.0
	s.step = 0.05
	s.value = value
	s.custom_minimum_size = Vector2(290, 36)
	s.value_changed.connect(func(v: float): on_change.call(v))
	s.drag_ended.connect(func(_changed: bool):
		Save.save()
		Audio.play("coin"))
	vb.add_child(s)
	return vb

func _build() -> void:
	UI.clear(box)
	box.add_theme_constant_override("separation", 9)
	box.add_child(UI.label("SETTINGS", 38, Color(1.0, 0.86, 0.2), 9))

	var name_label: Label = UI.label("Player name (LAN)", 18, Color.WHITE, 4)
	box.add_child(name_label)
	var le: LineEdit = LineEdit.new()
	le.text = Save.player_name
	le.max_length = 12
	le.custom_minimum_size = Vector2(300, 50)
	le.text_changed.connect(func(t: String): Save.player_name = t)
	le.text_submitted.connect(func(_txt: String):
		Save.save()
		le.release_focus())
	le.focus_exited.connect(func(): Save.save())
	box.add_child(le)

	box.add_child(_slider("Sound effects", Save.sfx_volume, func(v: float): Save.sfx_volume = v))
	box.add_child(_slider("Music", Save.music_volume, func(v: float):
		Save.music_volume = v
		Audio.apply_volumes()))

	box.add_child(_toggle("Vibration", func(): return Save.vibrate, func(v: bool): Save.vibrate = v))
	box.add_child(_toggle("Low-end mode", func(): return Save.low_quality, func(v: bool): Save.low_quality = v))
	box.add_child(_toggle("Show FPS", func(): return Save.show_fps, func(v: bool): Save.show_fps = v))
	if OS.has_feature("pc"):
		box.add_child(_toggle("Fullscreen", func(): return bool(Save.data["fullscreen"]), func(v: bool):
			Save.data["fullscreen"] = v
			Save.apply_window()))

	var bgb: Button = UI.button("", "Button", Vector2(300, 52))
	bgb.add_theme_font_size_override("font_size", 22)
	var names: Array = ["Auto (day/night)", "Always day", "Always night"]
	bgb.text = "Sky: %s" % names[Save.bg_mode]
	bgb.pressed.connect(func():
		Save.bg_mode = (Save.bg_mode + 1) % 3
		Save.save()
		bgb.text = "Sky: %s" % names[Save.bg_mode])
	box.add_child(bgb)

	var reset: Button = UI.button("RESET PROGRESS", "ButtonRed", Vector2(300, 48))
	reset.add_theme_font_size_override("font_size", 20)
	reset.pressed.connect(func():
		if not _reset_armed:
			_reset_armed = true
			reset.text = "TAP AGAIN TO CONFIRM"
			get_tree().create_timer(3.0).timeout.connect(func():
				if is_instance_valid(reset):
					_reset_armed = false
					reset.text = "RESET PROGRESS")
		else:
			Save.reset_progress()
			_reset_armed = false
			reset.text = "PROGRESS RESET")
	box.add_child(reset)

	var back: Button = UI.button("BACK", "ButtonGreen", Vector2(200, 54))
	back.pressed.connect(func():
		Save.save()
		Transition.go("res://scenes/main_menu.tscn"))
	box.add_child(back)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		Save.save()
		Transition.go("res://scenes/main_menu.tscn")
