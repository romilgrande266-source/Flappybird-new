extends RefCounted
## Draws the parallax sky / stars / sun / moon / clouds / hills / ground.
## Called from inside a CanvasItem's _draw().

const Assets = preload("res://scripts/assets.gd")

static func _tile(ci: CanvasItem, t: Texture2D, scroll: float, y: float, w: float, mod: Color) -> void:
	var tw: float = float(t.get_width())
	var th: float = float(t.get_height())
	var x: float = -fposmod(scroll, tw)
	while x < w:
		ci.draw_texture_rect(t, Rect2(floorf(x), y, tw + 1.0, th), false, mod)
		x += tw

static func draw_back(ci: CanvasItem, w: float, h: float, scroll: float, night: float, ground_h: float, low: bool) -> void:
	var gy: float = h - ground_h
	var sky_rect: Rect2 = Rect2(0, 0, w, gy + 24.0)
	ci.draw_texture_rect(Assets.tex("sky_day"), sky_rect, false)
	if night > 0.01:
		ci.draw_texture_rect(Assets.tex("sky_night"), sky_rect, false, Color(1, 1, 1, night))
		if not low:
			_tile(ci, Assets.tex("stars"), scroll * 0.03, 0.0, w, Color(1, 1, 1, night))
	var sun: Texture2D = Assets.tex("sun")
	var moon: Texture2D = Assets.tex("moon")
	var cx: float = w - 90.0
	ci.draw_texture(sun, Vector2(cx - 48.0, 70.0 + night * 120.0), Color(1, 1, 1, 1.0 - night))
	ci.draw_texture(moon, Vector2(cx - 48.0, 190.0 - night * 120.0), Color(1, 1, 1, night))
	if not low:
		_tile(ci, Assets.tex("clouds"), scroll * 0.12, gy - 520.0, w, Color(1, 1, 1, 1.0 - night * 0.65))
	var hy: float = gy - 214.0
	_tile(ci, Assets.tex("hills_day"), scroll * 0.3, hy, w, Color(1, 1, 1, 1.0))
	if night > 0.01:
		_tile(ci, Assets.tex("hills_night"), scroll * 0.3, hy, w, Color(1, 1, 1, night))

static func draw_ground(ci: CanvasItem, w: float, h: float, scroll: float, ground_h: float, night: float) -> void:
	var m: float = 1.0 - night * 0.35
	_tile(ci, Assets.tex("ground"), scroll, h - ground_h, w, Color(m, m, m * 1.05, 1.0))
