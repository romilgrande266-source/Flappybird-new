extends Control
## LAN lobby: create room / join room (auto discovery + manual IP) / ready system.

const UI = preload("res://scripts/ui.gd")
const Assets = preload("res://scripts/assets.gd")

var box: VBoxContainer
var state: String = "menu"          # menu | join | lobby
var status: Label
var rooms_box: VBoxContainer
var ip_edit: LineEdit

func _ready() -> void:
	box = UI.build_screen(self)
	Net.players_changed.connect(_on_players_changed)
	Net.rooms_changed.connect(_refresh_rooms)
	Net.joined.connect(_on_joined)
	Net.join_failed.connect(_on_join_failed)
	Net.match_started.connect(_on_match_started)
	Net.host_lost.connect(_on_host_lost)
	Net.connection_lost.connect(func(): _set_status("Connection lost..."))
	Net.reconnecting.connect(func(a: int, m: int): _set_status("Reconnecting (%d/%d)..." % [a, m]))
	Net.reconnected.connect(func():
		_set_status("")
		_render())
	if Net.active and (Net.phase == "lobby" or Net.phase == "results"):
		state = "lobby"
	_render()

func _set_status(t: String) -> void:
	if is_instance_valid(status):
		status.text = t

func _status_label() -> Label:
	status = UI.wrap_label("", 18, Color(1, 0.85, 0.5), 300)
	return status

func _render() -> void:
	UI.clear(box)
	box.add_theme_constant_override("separation", 10)
	match state:
		"menu": _render_menu()
		"join": _render_join()
		"lobby": _render_lobby()

func _title(t: String) -> void:
	box.add_child(UI.label(t, 28, Color(1.0, 0.86, 0.2), 8))

func _render_menu() -> void:
	Net.stop_discovery()
	_title("LAN MULTIPLAYER")
	box.add_child(UI.wrap_label("Connect all devices to the same Wi-Fi. No internet needed.", 18, Color.WHITE, 300))
	box.add_child(UI.spacer(10))
	var create: Button = UI.button("CREATE ROOM", "ButtonGreen")
	create.pressed.connect(_create_room)
	box.add_child(create)
	var join: Button = UI.button("JOIN ROOM")
	join.pressed.connect(func():
		state = "join"
		Net.start_discovery()
		_render())
	box.add_child(join)
	box.add_child(_status_label())
	var back: Button = UI.button("BACK", "ButtonRed", Vector2(200, 56))
	back.pressed.connect(func(): Transition.go("res://scenes/main_menu.tscn"))
	box.add_child(back)

func _create_room() -> void:
	var err: int = Net.host_room(Save.player_name, "%s's room" % Save.player_name)
	if err != OK:
		_set_status("Could not create room (error %d). Is port %d in use?" % [err, Net.GAME_PORT])
		return
	state = "lobby"
	_render()

func _render_join() -> void:
	_title("JOIN ROOM")
	box.add_child(UI.label("Rooms found on your Wi-Fi", 20, Color.WHITE, 4))
	rooms_box = VBoxContainer.new()
	rooms_box.add_theme_constant_override("separation", 8)
	box.add_child(rooms_box)
	_refresh_rooms()
	box.add_child(UI.label("or enter the host IP", 18, Color.WHITE, 4))
	ip_edit = LineEdit.new()
	ip_edit.placeholder_text = "192.168.1.23"
	ip_edit.text = str(Save.data.get("last_ip", ""))
	ip_edit.custom_minimum_size = Vector2(300, 50)
	ip_edit.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_URL
	box.add_child(ip_edit)
	var conn: Button = UI.button("CONNECT", "ButtonGreen", Vector2(300, 56))
	conn.pressed.connect(func(): _connect(ip_edit.text, Net.GAME_PORT))
	box.add_child(conn)
	box.add_child(_status_label())
	var back: Button = UI.button("BACK", "ButtonRed", Vector2(200, 56))
	back.pressed.connect(func():
		state = "menu"
		_render())
	box.add_child(back)

func _refresh_rooms() -> void:
	if state != "join" or not is_instance_valid(rooms_box):
		return
	UI.clear(rooms_box)
	if Net.rooms.is_empty():
		rooms_box.add_child(UI.label("Searching...", 18, Color(1, 1, 1, 0.8), 3))
		return
	for ip in Net.rooms:
		var r: Dictionary = Net.rooms[ip]
		var joinable: bool = r["phase"] == "lobby" and r["n"] < r["max"]
		var b: Button = UI.button("%s  (%d/%d)" % [r["room"], r["n"], r["max"]], "ButtonGreen" if joinable else "Button", Vector2(300, 54))
		b.add_theme_font_size_override("font_size", 20)
		b.disabled = not joinable
		var ip_s: String = str(ip)
		var port: int = int(r["port"])
		b.pressed.connect(func(): _connect(ip_s, port))
		rooms_box.add_child(b)

func _connect(ip: String, port: int) -> void:
	_set_status("Connecting to %s ..." % ip)
	Net.stop_discovery()
	var err: int = Net.join_room(ip, port, Save.player_name)
	if err != OK:
		Net.start_discovery()

func _on_joined() -> void:
	state = "lobby"
	_render()

func _on_join_failed(reason: String) -> void:
	state = "join"
	Net.start_discovery()
	_render()
	_set_status(reason)

func _on_host_lost() -> void:
	state = "menu"
	_render()
	_set_status("The host left the room.")

func _on_match_started(_s: int) -> void:
	Save.current_mode = "lan"
	Transition.go("res://scenes/game.tscn")

func _on_players_changed() -> void:
	if state == "lobby":
		_render()

func _render_lobby() -> void:
	_title("LOBBY")
	if Net.is_host:
		var ips: Array = Net.local_ips()
		var ip_text: String = "Your IP: %s" % (ips[0] if ips.size() > 0 else "unknown (is Wi-Fi on?)")
		box.add_child(UI.wrap_label("%s\nOthers can join automatically or type this IP." % ip_text, 17, Color.WHITE, 310))
	else:
		box.add_child(UI.label(Net.room_name, 22, Color.WHITE, 5))
	for tok in Net.players:
		box.add_child(_player_row(tok, Net.players[tok]))
	var me: bool = Net.is_ready(Net.my_token)
	var ready_btn: Button = UI.button("NOT READY" if me else "READY", "ButtonYellow" if me else "ButtonGreen")
	ready_btn.pressed.connect(func(): Net.set_ready(not me))
	box.add_child(ready_btn)
	if Net.is_host:
		var start: Button = UI.button("START MATCH", "ButtonGreen")
		start.disabled = not Net.can_start()
		start.pressed.connect(func(): Net.start_match())
		box.add_child(start)
		if not Net.can_start():
			box.add_child(UI.wrap_label("Need 2+ players, all READY.", 16, Color(1, 0.85, 0.5), 300))
	else:
		box.add_child(UI.wrap_label("Waiting for the host to start...", 16, Color(1, 0.85, 0.5), 300))
	box.add_child(_status_label())
	var leave: Button = UI.button("LEAVE ROOM", "ButtonRed", Vector2(220, 56))
	leave.pressed.connect(_leave)
	box.add_child(leave)

func _player_row(tok: String, p: Dictionary) -> Control:
	var pc: PanelContainer = PanelContainer.new()
	var hb: HBoxContainer = HBoxContainer.new()
	hb.add_theme_constant_override("separation", 10)
	pc.add_child(hb)
	var tr: TextureRect = TextureRect.new()
	tr.texture = Assets.bird(int(p["skin"]), 1)
	tr.custom_minimum_size = Vector2(46, 34)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	hb.add_child(tr)
	var nm: String = str(p["name"])
	if tok == Net.my_token:
		nm += " (you)"
	var name_l: Label = UI.label(nm, 20, Color.WHITE, 3)
	name_l.custom_minimum_size = Vector2(140, 0)
	name_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	hb.add_child(name_l)
	var st: String = "READY" if p["ready"] else "WAITING"
	var col: Color = Color(0.5, 1, 0.5) if p["ready"] else Color(1, 0.85, 0.5)
	if not p["connected"]:
		st = "OFFLINE"
		col = Color(1, 0.5, 0.5)
	hb.add_child(UI.label(st, 16, col, 3))
	return pc

func _leave() -> void:
	Net.leave()
	state = "menu"
	_render()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		match state:
			"menu":
				Transition.go("res://scenes/main_menu.tscn")
			"join":
				state = "menu"
				_render()
			_:
				_leave()
