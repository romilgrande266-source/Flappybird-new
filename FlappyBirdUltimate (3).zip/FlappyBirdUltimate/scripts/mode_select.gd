extends Control

const UI = preload("res://scripts/ui.gd")

var box: VBoxContainer
var in_levels: bool = false

func _ready() -> void:
	box = UI.build_screen(self)
	_show_modes()

func _start(mode: String, level: int = 0) -> void:
	Save.current_mode = mode
	Save.current_level = level
	Audio.play("swoosh")
	Transition.go("res://scenes/game.tscn")

func _mode_button(text: String, desc: String, variant: String, cb: Callable) -> void:
	var b: Button = UI.button(text, variant, Vector2(300, 58))
	b.pressed.connect(cb)
	box.add_child(b)
	box.add_child(UI.label(desc, 15, Color(1, 1, 1, 0.95), 4))

func _show_modes() -> void:
	in_levels = false
	UI.clear(box)
	box.add_theme_constant_override("separation", 6)
	box.add_child(UI.label("SELECT MODE", 38, Color(1.0, 0.86, 0.2), 9))
	box.add_child(UI.spacer(4))
	_mode_button("CLASSIC", "One life. Best %d" % Save.best("classic"), "ButtonGreen", func(): _start("classic"))
	_mode_button("ENDLESS", "3 lives, coins, rising difficulty. Best %d" % Save.best("endless"), "Button", func(): _start("endless"))
	_mode_button("CHALLENGE", "10 levels. Completed %d/10" % int(Save.data["challenge_done"]), "ButtonYellow", func(): _show_levels())
	_mode_button("2 PLAYERS", "Same device. Tap left / right side", "Button", func(): _start("local2p"))
	_mode_button("LAN MULTIPLAYER", "Race friends over Wi-Fi", "Button", func(): Transition.go("res://scenes/lobby.tscn"))
	_mode_button("PRACTICE", "Slow, wide gaps, no risk", "Button", func(): _start("practice"))
	box.add_child(UI.spacer(4))
	var back: Button = UI.button("BACK", "ButtonRed", Vector2(200, 56))
	back.pressed.connect(func(): Transition.go("res://scenes/main_menu.tscn"))
	box.add_child(back)

func _show_levels() -> void:
	in_levels = true
	UI.clear(box)
	box.add_theme_constant_override("separation", 12)
	box.add_child(UI.label("CHALLENGE", 38, Color(1.0, 0.86, 0.2), 9))
	var done: int = int(Save.data["challenge_done"])
	box.add_child(UI.label("Reach the target score on each level", 18, Color.WHITE, 4))
	var grid: GridContainer = GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	box.add_child(grid)
	for i in range(Save.CHALLENGE_LEVELS.size()):
		var lv: Dictionary = Save.CHALLENGE_LEVELS[i]
		var unlocked: bool = i <= done
		var b: Button = UI.button("%d\n%d pipes" % [i + 1, lv["target"]], "ButtonGreen" if i < done else "Button", Vector2(96, 84))
		b.add_theme_font_size_override("font_size", 20)
		b.disabled = not unlocked
		var idx: int = i
		b.pressed.connect(func(): _start("challenge", idx))
		grid.add_child(b)
	box.add_child(UI.spacer(6))
	var back: Button = UI.button("BACK", "ButtonRed", Vector2(200, 56))
	back.pressed.connect(func(): _show_modes())
	box.add_child(back)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if in_levels:
			_show_modes()
		else:
			Transition.go("res://scenes/main_menu.tscn")
