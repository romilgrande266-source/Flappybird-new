extends Node
## Sound effects (pooled players) and looping background music.

const SFX_NAMES: Array = ["flap", "score", "hit", "die", "swoosh", "click", "coin", "win", "countdown"]

var _sfx: Dictionary = {}
var _pool: Array = []
var _idx: int = 0
var _music: AudioStreamPlayer

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for n in SFX_NAMES:
		var p: String = "res://assets/audio/%s.wav" % n
		if ResourceLoader.exists(p):
			_sfx[n] = load(p)
	for i in range(8):
		var pl: AudioStreamPlayer = AudioStreamPlayer.new()
		add_child(pl)
		_pool.append(pl)
	_music = AudioStreamPlayer.new()
	add_child(_music)
	var mp: String = "res://assets/audio/music.wav"
	if ResourceLoader.exists(mp):
		var m: AudioStreamWAV = load(mp)
		var bytes_per_sample: int = 2 if m.format == AudioStreamWAV.FORMAT_16_BITS else 1
		if m.stereo:
			bytes_per_sample *= 2
		m.loop_mode = AudioStreamWAV.LOOP_FORWARD
		m.loop_begin = 0
		m.loop_end = int(m.data.size() / bytes_per_sample)
		_music.stream = m
	apply_volumes()

func apply_volumes() -> void:
	_music.volume_db = linear_to_db(maxf(Save.music_volume, 0.0001)) - 4.0
	if Save.music_volume <= 0.001:
		_music.stop()
	elif _music.stream != null and not _music.playing:
		_music.play()

func play_music() -> void:
	if _music.stream != null and Save.music_volume > 0.001 and not _music.playing:
		_music.play()

func play(sfx_name: String, pitch: float = 1.0) -> void:
	if Save.sfx_volume <= 0.001 or not _sfx.has(sfx_name):
		return
	var p: AudioStreamPlayer = _pool[_idx]
	_idx = (_idx + 1) % _pool.size()
	p.stream = _sfx[sfx_name]
	p.pitch_scale = pitch
	p.volume_db = linear_to_db(Save.sfx_volume)
	p.play()
