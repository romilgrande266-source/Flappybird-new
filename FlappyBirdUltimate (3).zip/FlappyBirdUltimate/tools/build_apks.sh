#!/usr/bin/env bash
# Builds exports/FlappyBirdUltimate-arm32.apk and exports/FlappyBirdUltimate-arm64.apk
#   EXPORT_MODE=debug (default) | release   - release needs GODOT_ANDROID_KEYSTORE_RELEASE_* variables
#   GODOT_BIN=godot                          - path of the Godot 4.3 editor binary
set -euo pipefail
cd "$(dirname "$0")/.."
GODOT_BIN="${GODOT_BIN:-godot}"
MODE="${EXPORT_MODE:-debug}"
export GODOT_ANDROID_KEYSTORE_DEBUG_PATH="${GODOT_ANDROID_KEYSTORE_DEBUG_PATH:-${DEBUG_KEYSTORE:-$HOME/.android/debug.keystore}}"
export GODOT_ANDROID_KEYSTORE_DEBUG_USER="${GODOT_ANDROID_KEYSTORE_DEBUG_USER:-androiddebugkey}"
export GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD="${GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD:-android}"

mkdir -p exports
# Two import passes: the first builds the asset cache, the second the script/class cache.
"$GODOT_BIN" --headless --path . --import || true
"$GODOT_BIN" --headless --path . --import || true

for abi in arm32 arm64; do
  echo ">> Exporting Android $abi ($MODE)"
  "$GODOT_BIN" --headless --path . "--export-$MODE" "Android $abi" "exports/FlappyBirdUltimate-$abi.apk"
done

# Verify ABIs inside the packages
unzip -l exports/FlappyBirdUltimate-arm64.apk | grep -q "lib/arm64-v8a/"   || { echo "arm64 APK has no arm64-v8a libs"; exit 1; }
unzip -l exports/FlappyBirdUltimate-arm32.apk | grep -q "lib/armeabi-v7a/" || { echo "arm32 APK has no armeabi-v7a libs"; exit 1; }
if unzip -l exports/FlappyBirdUltimate-arm64.apk | grep -q "lib/armeabi-v7a/"; then echo "arm64 APK contains 32-bit libs"; exit 1; fi
if unzip -l exports/FlappyBirdUltimate-arm32.apk | grep -q "lib/arm64-v8a/";   then echo "arm32 APK contains 64-bit libs"; exit 1; fi
ls -la exports/*.apk
