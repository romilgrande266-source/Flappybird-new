#!/usr/bin/env python3
"""Generates every original sprite, background, UI element and audio file of
Flappy Bird Ultimate. Requires: Pillow, numpy.  Usage: python3 tools/generate_assets.py"""
import math, os, random, wave
import numpy as np
from PIL import Image, ImageDraw

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets")
SPR, BG, ANIM, AUD = (os.path.join(ROOT, d) for d in ("sprites", "backgrounds", "animations", "audio"))
for d in (SPR, BG, ANIM, AUD):
    os.makedirs(d, exist_ok=True)
S = 4  # supersampling


def save(img, folder, name):
    img.save(os.path.join(folder, name + ".png"))


def new(w, h, color=(0, 0, 0, 0)):
    return Image.new("RGBA", (w * S, h * S), color)


def down(img):
    return img.resize((img.width // S, img.height // S), Image.LANCZOS)


def poly_ellipse(cx, cy, rx, ry, ang=0.0, n=48):
    pts = []
    ca, sa = math.cos(math.radians(ang)), math.sin(math.radians(ang))
    for i in range(n):
        t = 2 * math.pi * i / n
        x, y = rx * math.cos(t), ry * math.sin(t)
        pts.append(((cx + x * ca - y * sa) * S, (cy + x * sa + y * ca) * S))
    return pts


def ell(d, cx, cy, rx, ry, fill, ang=0.0):
    d.polygon(poly_ellipse(cx, cy, rx, ry, ang), fill=fill)


def rrect(d, box, r, fill, outline=None, width=0):
    b = [v * S for v in box]
    d.rounded_rectangle(b, radius=r * S, fill=fill, outline=outline, width=width * S)


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(len(a)))


# ---------------------------------------------------------------- birds
SKINS = [  # body, belly, wing
    ((255, 213, 50), (255, 244, 180), (255, 150, 40)),
    ((232, 70, 76), (255, 196, 186), (160, 28, 52)),
    ((86, 176, 242), (206, 238, 255), (36, 96, 200)),
    ((92, 212, 132), (214, 252, 224), (36, 146, 88)),
    ((172, 112, 232), (232, 214, 252), (104, 56, 178)),
    ((255, 192, 24), (255, 238, 124), (214, 138, 8)),
]
OUT = (58, 36, 40, 255)


def bird(skin, frame):
    body, belly, wing = SKINS[skin]
    im = new(56, 42)
    d = ImageDraw.Draw(im)
    ell(d, 6, 20, 7, 4, OUT, -20)
    ell(d, 6, 20, 5, 2.4, wing + (255,), -20)
    ell(d, 27, 22, 22, 17, OUT)
    ell(d, 27, 22, 20, 15, body + (255,))
    ell(d, 31, 29, 14, 7.5, belly + (255,))
    ell(d, 38, 25, 4, 2.6, (255, 150, 150, 150))
    wy, wa = [(14, -38), (22, 0), (29, 34)][frame]
    ell(d, 19, wy, 11.5, 6.8, OUT, wa)
    ell(d, 19, wy, 10, 5.4, wing + (255,), wa)
    ell(d, 16, wy - 1.5, 5, 1.8, lerp(wing, (255, 255, 255), .35) + (255,), wa)
    ell(d, 38, 14, 8, 8, OUT)
    ell(d, 38, 14, 6.6, 6.6, (255, 255, 255, 255))
    ell(d, 40.2, 14.4, 3.1, 3.1, (30, 24, 30, 255))
    ell(d, 41.2, 13.2, 1.0, 1.0, (255, 255, 255, 255))
    ell(d, 49, 22, 7.5, 4.4, OUT)
    ell(d, 49, 21, 6, 3, (255, 128, 40, 255))
    ell(d, 48, 26, 5.5, 2.6, OUT)
    ell(d, 48, 25.5, 4.2, 1.6, (232, 78, 40, 255))
    if skin == 5:  # golden crown
        d.polygon([(x * S, y * S) for x, y in [(21, 8), (23, -1), (28, 5), (33, -2), (36, 6), (41, 0), (40, 9)]], fill=OUT)
        d.polygon([(x * S, y * S) for x, y in [(23, 8), (24, 2), (28, 6), (33, 1), (35, 7), (39, 3), (38, 8)]], fill=(255, 236, 90, 255))
    return down(im)


for s in range(len(SKINS)):
    for f in range(3):
        save(bird(s, f), ANIM, f"bird_{s}_{f}")


# ---------------------------------------------------------------- pipes
def pipe_col(t, base=(104, 200, 70), dark=(52, 124, 44), light=(176, 238, 120)):
    if t < .10:
        return lerp((40, 70, 36), dark, t / .10)
    if t < .30:
        return lerp(base, light, (t - .10) / .20)
    if t < .55:
        return lerp(light, base, (t - .30) / .25)
    if t < .90:
        return lerp(base, dark, (t - .55) / .35)
    return lerp(dark, (40, 70, 36), (t - .90) / .10)


def pipe_body():
    w, h = 72, 32
    im = Image.new("RGBA", (w, h))
    px = im.load()
    for x in range(w):
        c = pipe_col(x / (w - 1))
        for y in range(h):
            px[x, y] = c + (255,)
    for x in (0, 1, w - 2, w - 1):
        for y in range(h):
            px[x, y] = (40, 70, 36, 255)
    return im


def pipe_cap():
    w, h = 80, 36
    im = new(w, h)
    d = ImageDraw.Draw(im)
    rrect(d, (0, 0, w, h), 6, (40, 70, 36, 255))
    for x in range(2, w - 2):
        d.rectangle([x * S, 3 * S, (x + 1) * S, (h - 3) * S], fill=pipe_col(x / (w - 1)) + (255,))
    return down(im)


save(pipe_body(), SPR, "pipe_body")
save(pipe_cap(), SPR, "pipe_cap")


# ---------------------------------------------------------------- coin / fx animations
def coin(frame):
    im = new(32, 32)
    d = ImageDraw.Draw(im)
    rx = [13, 9, 4, 9][frame]
    ell(d, 16, 16, rx + 2, 15, (150, 90, 10, 255))
    ell(d, 16, 16, rx, 13, (255, 206, 40, 255))
    if rx > 6:
        ell(d, 16, 16, rx - 4, 9, (255, 232, 110, 255))
        d.rectangle([14.2 * S, 10 * S, 17.8 * S, 22 * S], fill=(230, 160, 20, 255))
    return down(im)


for f in range(4):
    save(coin(f), ANIM, f"coin_{f}")


def puff(frame):
    im = new(96, 96)
    d = ImageDraw.Draw(im)
    t = frame / 5.0
    r = 10 + 34 * t
    a = int(255 * (1 - t))
    for i in range(8):
        ang = i * math.pi / 4 + .4
        x, y = 48 + math.cos(ang) * r, 48 + math.sin(ang) * r
        ell(d, x, y, 7 * (1 - t) + 1, 7 * (1 - t) + 1, (255, 240, 170, a))
    ell(d, 48, 48, r * .5, r * .5, (255, 255, 255, int(a * .35)))
    return down(im)


for f in range(6):
    save(puff(f), ANIM, f"puff_{f}")

px = Image.new("RGBA", (16, 16))
for y in range(16):
    for x in range(16):
        dd = math.hypot(x - 7.5, y - 7.5) / 8
        px.putpixel((x, y), (255, 255, 255, int(255 * max(0, 1 - dd ** 2))))
save(px, SPR, "particle")


# ---------------------------------------------------------------- backgrounds
def gradient(w, h, stops):
    im = Image.new("RGBA", (w, h))
    for y in range(h):
        t = y / (h - 1)
        c = stops[-1][1]
        for i in range(len(stops) - 1):
            if stops[i][0] <= t <= stops[i + 1][0]:
                u = (t - stops[i][0]) / (stops[i + 1][0] - stops[i][0])
                c = lerp(stops[i][1], stops[i + 1][1], u)
                break
        for x in range(w):
            im.putpixel((x, y), c + (255,))
    return im


save(gradient(16, 512, [(0, (74, 168, 226)), (.6, (150, 214, 240)), (1, (214, 240, 238))]), BG, "sky_day")
save(gradient(16, 512, [(0, (10, 14, 44)), (.6, (30, 40, 94)), (1, (84, 74, 134))]), BG, "sky_night")

random.seed(7)
im = Image.new("RGBA", (512, 500), (0, 0, 0, 0))
d = ImageDraw.Draw(im)
for _ in range(90):
    x, y, r = random.randint(0, 511), random.randint(0, 460), random.choice([1, 1, 1, 2])
    a = random.randint(150, 255)
    for ox in (0, -512, 512):
        d.ellipse([x - r + ox, y - r, x + r + ox, y + r], fill=(255, 255, 230, a))
save(im, BG, "stars")


def clouds():
    im = new(512, 160)
    d = ImageDraw.Draw(im)
    for cx, cy, sc in [(70, 100, 1.0), (200, 60, .8), (330, 110, 1.15), (450, 70, .9)]:
        for ox in (0, -512, 512):
            for dx, dy, r in [(-34, 8, 22), (-12, -6, 28), (16, -2, 30), (40, 8, 22), (0, 14, 26)]:
                ell(d, cx + ox + dx * sc, cy + dy * sc, r * sc, r * sc * .8, (255, 255, 255, 215))
    return down(im)


save(clouds(), BG, "clouds")


def hills(col_a, col_b, win=None):
    im = new(512, 220)
    d = ImageDraw.Draw(im)
    for layer, (col, base, amp, f1, f2) in enumerate([(col_b, 120, 34, 2, 5), (col_a, 160, 26, 3, 7)]):
        pts = [(0, 220 * S)]
        for x in range(0, 513, 4):
            y = base + amp * math.sin(2 * math.pi * f1 * x / 512 + layer) + amp * .4 * math.sin(2 * math.pi * f2 * x / 512)
            pts.append((x * S, y * S))
        pts.append((512 * S, 220 * S))
        d.polygon(pts, fill=col + (255,))
    if win:
        random.seed(5)
        x = 0
        while x < 512:
            w, h = random.randint(24, 48), random.randint(50, 120)
            w = min(w, 512 - x)
            d.rectangle([x * S, (220 - h) * S, (x + w) * S, 220 * S], fill=win[0] + (255,))
            for wy in range(220 - h + 8, 212, 14):
                for wx in range(x + 6, x + w - 8, 12):
                    if random.random() < .45:
                        d.rectangle([wx * S, wy * S, (wx + 5) * S, (wy + 7) * S], fill=win[1] + (255,))
            x += w + 2
    return down(im)


save(hills((112, 196, 112), (150, 214, 150)), BG, "hills_day")
save(hills((26, 40, 76), (40, 54, 100), win=((20, 28, 56), (255, 220, 120))), BG, "hills_night")


def disc(kind):
    im = new(96, 96)
    d = ImageDraw.Draw(im)
    if kind == "sun":
        for r, a in [(46, 60), (40, 90), (34, 255)]:
            ell(d, 48, 48, r, r, (255, 226, 110, a))
    else:
        ell(d, 48, 48, 30, 30, (246, 244, 220, 255))
        for cx, cy, r in [(40, 42, 5), (54, 56, 4), (38, 58, 3)]:
            ell(d, cx, cy, r, r, (214, 212, 190, 255))
    return down(im)


save(disc("sun"), BG, "sun")
save(disc("moon"), BG, "moon")

# ground tile 64x112 (tileable horizontally)
g = Image.new("RGBA", (64, 112), (222, 196, 120, 255))
gd = ImageDraw.Draw(g)
gd.rectangle([0, 0, 64, 10], fill=(110, 200, 70, 255))
gd.rectangle([0, 10, 64, 14], fill=(70, 140, 50, 255))
gd.rectangle([0, 14, 64, 17], fill=(120, 90, 50, 255))
for x in range(-32, 96, 16):
    gd.polygon([(x, 17), (x + 8, 17), (x + 24, 36), (x + 16, 36)], fill=(204, 176, 100, 255))
for x in range(4, 64, 16):
    gd.ellipse([x, 60, x + 4, 64], fill=(196, 166, 92, 255))
    gd.ellipse([x + 8, 84, x + 12, 88], fill=(196, 166, 92, 255))
save(g, SPR, "ground")


# ---------------------------------------------------------------- UI
def button(name, col, pressed=False):
    base = col if not pressed else lerp(col, (0, 0, 0), .15)
    dark = lerp(col, (0, 0, 0), .4)
    lite = lerp(col, (255, 255, 255), .35)
    im = new(64, 64)
    d = ImageDraw.Draw(im)
    top = 4 if pressed else 0
    rrect(d, (0, 6, 64, 62), 18, dark + (255,))
    rrect(d, (0, top, 64, 56 + top), 18, (40, 30, 50, 255))
    rrect(d, (3, top + 3, 61, 53 + top), 15, base + (255,))
    if not pressed:
        rrect(d, (7, top + 6, 57, 24), 10, lite + (110,))
    save(down(im), SPR, name)


for nm, col in [("blue", (64, 150, 230)), ("green", (84, 196, 90)), ("red", (232, 80, 80)), ("yellow", (244, 182, 40))]:
    button(f"btn_{nm}", col)
    button(f"btn_{nm}_down", col, True)
button("btn_gray", (140, 146, 160))

im = new(64, 64)
d = ImageDraw.Draw(im)
rrect(d, (0, 0, 64, 64), 20, (255, 255, 255, 255))
rrect(d, (3, 3, 61, 61), 17, (28, 38, 74, 238))
save(down(im), SPR, "panel")


def icon(name, fn):
    im = new(64, 64)
    d = ImageDraw.Draw(im)
    fn(d)
    save(down(im), SPR, name)


W = (255, 255, 255, 255)


def i_pause(d):
    ell(d, 32, 32, 29, 29, (28, 38, 74, 220))
    ell(d, 32, 32, 27, 27, (255, 255, 255, 40))
    rrect(d, (21, 18, 29, 46), 3, W)
    rrect(d, (35, 18, 43, 46), 3, W)


def i_heart(d):
    ell(d, 22, 24, 13, 13, (60, 20, 40, 255))
    ell(d, 42, 24, 13, 13, (60, 20, 40, 255))
    d.polygon([(8 * S, 28 * S), (56 * S, 28 * S), (32 * S, 58 * S)], fill=(60, 20, 40, 255))
    ell(d, 22, 24, 11, 11, (240, 70, 90, 255))
    ell(d, 42, 24, 11, 11, (240, 70, 90, 255))
    d.polygon([(11 * S, 28 * S), (53 * S, 28 * S), (32 * S, 54 * S)], fill=(240, 70, 90, 255))
    ell(d, 18, 20, 4, 3, (255, 190, 200, 255))


def i_coin(d):
    ell(d, 32, 32, 29, 29, (150, 90, 10, 255))
    ell(d, 32, 32, 26, 26, (255, 206, 40, 255))
    ell(d, 32, 32, 19, 19, (255, 232, 110, 255))
    rrect(d, (28, 20, 36, 44), 3, (230, 160, 20, 255))


def medal(col):
    def f(d):
        d.polygon([(18 * S, 2 * S), (30 * S, 2 * S), (36 * S, 30 * S), (24 * S, 30 * S)], fill=(220, 60, 60, 255))
        d.polygon([(46 * S, 2 * S), (34 * S, 2 * S), (28 * S, 30 * S), (40 * S, 30 * S)], fill=(60, 90, 220, 255))
        ell(d, 32, 40, 22, 22, lerp(col, (0, 0, 0), .45) + (255,))
        ell(d, 32, 40, 19, 19, col + (255,))
        ell(d, 32, 40, 13, 13, lerp(col, (255, 255, 255), .4) + (255,))
        star = [(32, 31), (35, 38), (42, 38), (36, 43), (38, 50), (32, 46), (26, 50), (28, 43), (22, 38), (29, 38)]
        d.polygon([(x * S, y * S) for x, y in star], fill=lerp(col, (0, 0, 0), .35) + (255,))
    return f


for nm, col in [("bronze", (205, 127, 50)), ("silver", (200, 206, 214)), ("gold", (255, 205, 40)), ("platinum", (130, 226, 240))]:
    icon(f"medal_{nm}", medal(col))
icon("icon_pause", i_pause)
icon("icon_heart", i_heart)
icon("icon_coin", i_coin)


def launcher(size, with_bg=True, scale=1.0):
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    if with_bg:
        im.paste(gradient(size, size, [(0, (74, 168, 226)), (.7, (150, 214, 240)), (1, (214, 240, 238))]), (0, 0))
        dd = ImageDraw.Draw(im)
        dd.rectangle([0, int(size * .84), size, size], fill=(222, 196, 120, 255))
        dd.rectangle([0, int(size * .84), size, int(size * .87)], fill=(110, 200, 70, 255))
    b = bird(0, 1)
    bw = int(size * .70 * scale)
    b = b.resize((bw, int(bw * 42 / 56)), Image.LANCZOS)
    im.alpha_composite(b, ((size - b.width) // 2, (size - b.height) // 2 - int(size * .04)))
    return im


save(launcher(192), SPR, "icon_192")
save(gradient(432, 432, [(0, (74, 168, 226)), (1, (214, 240, 238))]), SPR, "icon_bg_432")
save(launcher(432, False, .62), SPR, "icon_fg_432")

# ---------------------------------------------------------------- audio
SR = 22050


def env(n, a=.005, r=.08):
    e = np.ones(n)
    na, nr = max(1, int(a * SR)), max(1, int(r * SR))
    e[:na] = np.linspace(0, 1, na)
    e[-nr:] *= np.linspace(1, 0, nr)
    return e


def osc(kind, phase, duty=.5):
    if kind == "square":
        return np.where((phase % 1.0) < duty, 1.0, -1.0)
    if kind == "tri":
        return 2 * np.abs(2 * (phase % 1.0) - 1) - 1
    if kind == "saw":
        return 2 * (phase % 1.0) - 1
    return np.sin(2 * np.pi * phase)


def tone(f0, f1, dur, kind="square", vol=.5, duty=.5, a=.004, r=.06):
    n = int(dur * SR)
    f = np.linspace(f0, f1, n)
    ph = np.cumsum(f) / SR
    return osc(kind, ph, duty) * env(n, a, r) * vol


def noise(dur, vol=.5, lp=0.0, r=.1):
    n = int(dur * SR)
    x = np.random.RandomState(3).uniform(-1, 1, n)
    if lp > 0:
        for i in range(1, n):
            x[i] = x[i - 1] * lp + x[i] * (1 - lp)
    return x * env(n, .002, r) * vol


def write(name, data, gain=.9):
    data = np.asarray(data)
    m = np.max(np.abs(data)) or 1
    pcm = (data / m * gain * 32767).astype("<i2")
    with wave.open(os.path.join(AUD, name + ".wav"), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())


def pad(a, n):
    return np.pad(a, (0, max(0, n - len(a))))[:n]


def cat(*a):
    return np.concatenate(a)


write("flap", tone(380, 760, .11, "square", .5, .25, r=.05))
write("score", cat(tone(988, 988, .07, "square", .45, .5, r=.02), tone(1319, 1319, .16, "square", .45, .5, r=.12)))
write("coin", cat(tone(1568, 1568, .06, "square", .4, .25, r=.02), tone(2093, 2093, .18, "square", .4, .25, r=.14)))
hit = noise(.18, .8, .6, .15)
write("hit", hit + pad(tone(220, 70, .18, "saw", .5, r=.1), len(hit)))
write("die", tone(520, 140, .45, "square", .5, .5, r=.2))
write("swoosh", noise(.22, .6, .85, .2))
write("click", tone(660, 660, .045, "square", .4, .5, r=.03))
write("countdown", tone(880, 880, .12, "tri", .7, r=.06))
write("win", cat(*[tone(f, f, .13, "square", .45, .25, r=.05) for f in (523, 659, 784)], tone(1047, 1047, .4, "square", .45, .25, r=.3)))


def note(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def music():
    bpm = 118
    eighth = 60 / bpm / 2
    n8 = int(eighth * SR)
    chords = [(60, 64, 67), (55, 59, 62), (57, 60, 64), (53, 57, 60), (60, 64, 67), (55, 59, 62), (53, 57, 60), (55, 59, 62)]
    scale = [72, 74, 76, 79, 81, 84]
    rnd = random.Random(21)
    total = len(chords) * 8 * n8
    out = np.zeros(total)

    def put(pos, sig, gain):
        end = min(total, pos + len(sig))
        out[pos:end] += sig[:end - pos] * gain

    for bar, ch in enumerate(chords):
        for step in range(8):
            pos = (bar * 8 + step) * n8
            m = ch[step % 3] + 12
            put(pos, tone(note(m), note(m), eighth * .9, "square", .5, .25, r=.05), .30)
            if step % 4 == 0:
                put(pos, tone(note(ch[0] - 12), note(ch[0] - 12), eighth * 3.6, "tri", .9, r=.12), .55)
            if step % 2 == 0:
                lm = rnd.choice(scale + [c + 24 for c in ch])
                put(pos, tone(note(lm), note(lm), eighth * 1.8, "square", .5, .5, r=.12), .20)
            put(pos, noise(.04, .5, .2, .03), .10 if step % 2 else .16)
            if step in (0, 4):
                put(pos, tone(150, 45, .12, "sine", 1.0, r=.08), .6)
    return out


write("music", music(), .7)
print("assets generated in", os.path.abspath(ROOT))
