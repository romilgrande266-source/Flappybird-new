#!/usr/bin/env bash
# Prepares Godot's Android export environment (used by CI and usable locally on Linux).
# Expects: godot, JDK 17, Android SDK (cmdline-tools + build-tools 34 + platform 34), export templates.
set -euo pipefail

GODOT_VERSION="${GODOT_VERSION:-4.3}"
ANDROID_SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-/usr/lib/android-sdk}}"
JAVA_DIR="${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$(which javac)")")")}"
KEYSTORE="${DEBUG_KEYSTORE:-$HOME/.android/debug.keystore}"

# godot-ci keeps templates under /root; GitHub container jobs use a different $HOME.
SRC="/root/.local/share/godot/export_templates/${GODOT_VERSION}.stable"
DST="$HOME/.local/share/godot/export_templates/${GODOT_VERSION}.stable"
mkdir -p "$(dirname "$DST")" "$HOME/.config/godot" "$(dirname "$KEYSTORE")"
if [ -d "$SRC" ] && [ ! -d "$DST" ]; then cp -r "$SRC" "$DST"; fi
[ -d "$DST" ] || { echo "Export templates for Godot ${GODOT_VERSION} not found at $DST"; exit 1; }

if [ ! -f "$KEYSTORE" ]; then
  keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore "$KEYSTORE" \
    -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999 -deststoretype pkcs12
fi

for f in editor_settings-4.tres editor_settings-4.3.tres; do
cat > "$HOME/.config/godot/$f" <<EOT
[gd_resource type="EditorSettings" format=3]

[resource]
export/android/android_sdk_path = "$ANDROID_SDK"
export/android/java_sdk_path = "$JAVA_DIR"
export/android/debug_keystore = "$KEYSTORE"
export/android/debug_keystore_user = "androiddebugkey"
export/android/debug_keystore_pass = "android"
export/android/force_system_user = false
export/android/shutdown_adb_on_exit = true
EOT
done
echo "Godot Android environment ready (SDK=$ANDROID_SDK, JDK=$JAVA_DIR)"
