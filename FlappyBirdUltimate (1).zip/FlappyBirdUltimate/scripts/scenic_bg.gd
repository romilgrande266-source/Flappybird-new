extends Control
## Animated menu background (scrolling scenery, optional flying bird).

const Scenery = preload("res://scripts/scenery.gd")
const Assets = preload("res://scripts/assets.gd")

var scroll: float = 0.0
var night: float = 0.0
var show_bird: bool = false
var _t: float = 0.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	if Save.bg_mode == 2:
		night = 1.0

func _process(delta: float) -> void:
	scroll += 45.0 * delta
	_t += delta
	queue_redraw()

func _draw() -> void:
	var w: float = get_viewport_rect().size.x
	var h: float = 800.0
	Scenery.draw_back(self, w, h, scroll, night, 112.0, Save.low_quality)
	Scenery.draw_ground(self, w, h, scroll, 112.0, night)
	if show_bird:
		var t: Texture2D = Assets.bird(Save.skin, int(_t * 10.0) % 3)
		var p: Vector2 = Vector2(w * 0.5, 150.0 + sin(_t * 2.2) * 14.0)
		draw_set_transform(p, sin(_t * 2.2) * 0.12, Vector2(1.4, 1.4))
		draw_texture(t, -t.get_size() * 0.5)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
