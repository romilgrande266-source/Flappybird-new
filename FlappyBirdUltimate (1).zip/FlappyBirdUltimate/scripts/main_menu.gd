extends Control

const UI = preload("res://scripts/ui.gd")

func _ready() -> void:
	get_tree().set_auto_accept_quit(true)
	Audio.play_music()
	var box: VBoxContainer = UI.build_screen(self, true)
	box.add_child(UI.spacer(150))
	box.add_child(UI.label("FLAPPY BIRD", 42, Color(1.0, 0.86, 0.2), 10))
	box.add_child(UI.label("ULTIMATE", 34, Color.WHITE, 9))
	box.add_child(UI.spacer(10))
	var coin_bar: HBoxContainer = UI.coin_bar()
	box.add_child(coin_bar)
	var best: Label = UI.label("Best  Classic %d   Endless %d" % [Save.best("classic"), Save.best("endless")], 18, Color.WHITE, 4)
	box.add_child(best)
	box.add_child(UI.spacer(8))

	var play: Button = UI.button("PLAY", "ButtonGreen")
	play.pressed.connect(func(): Transition.go("res://scenes/mode_select.tscn"))
	box.add_child(play)

	var lan: Button = UI.button("LAN MULTIPLAYER")
	lan.pressed.connect(func(): Transition.go("res://scenes/lobby.tscn"))
	box.add_child(lan)

	var shop: Button = UI.button("BIRD SHOP", "ButtonYellow")
	shop.pressed.connect(func(): Transition.go("res://scenes/shop.tscn"))
	box.add_child(shop)

	var settings: Button = UI.button("SETTINGS")
	settings.pressed.connect(func(): Transition.go("res://scenes/settings.tscn"))
	box.add_child(settings)

	var quit: Button = UI.button("QUIT", "ButtonRed")
	quit.pressed.connect(func(): get_tree().quit())
	box.add_child(quit)

	var ver: Label = UI.label("v%s  -  offline, no account needed" % str(ProjectSettings.get_setting("application/config/version", "1.0.0")), 15, Color(1, 1, 1, 0.9), 4)
	box.add_child(ver)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		get_tree().quit()
