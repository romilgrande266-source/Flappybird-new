extends CanvasLayer
## Fade screen transitions: Transition.go("res://scenes/x.tscn")

var _rect: ColorRect
var busy: bool = false

func _ready() -> void:
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	_rect = ColorRect.new()
	_rect.color = Color(0.06, 0.1, 0.2, 1.0)
	_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_rect.modulate.a = 0.0
	add_child(_rect)

func go(path: String) -> void:
	if busy:
		return
	busy = true
	_rect.mouse_filter = Control.MOUSE_FILTER_STOP
	var t: Tween = create_tween()
	t.tween_property(_rect, "modulate:a", 1.0, 0.2)
	await t.finished
	get_tree().paused = false
	get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	await get_tree().process_frame
	var t2: Tween = create_tween()
	t2.tween_property(_rect, "modulate:a", 0.0, 0.25)
	await t2.finished
	_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	busy = false
