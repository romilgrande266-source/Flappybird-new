extends Node2D
## Gameplay for every mode: classic, endless, challenge, local2p, lan, practice.
## The world is always 800 units high (stretch aspect "keep_height"), so portrait and
## landscape play identically; only the visible width changes.

const UI = preload("res://scripts/ui.gd")
const Assets = preload("res://scripts/assets.gd")
const Scenery = preload("res://scripts/scenery.gd")

const WORLD_H: float = 800.0
const GROUND_H: float = 112.0
const PLAY_H: float = 688.0
const BIRD_X: float = 130.0
const GRAVITY: float = 1800.0
const FLAP_V: float = -520.0
const MAX_FALL: float = 760.0
const BIRD_R: float = 15.0
const PIPE_W: float = 80.0
const CAP_H: float = 36.0
const PIPE_SPACING: float = 260.0

enum State { READY, COUNTDOWN, PLAYING, ENDED }

class Bird:
	var token: String = ""
	var pname: String = ""
	var skin: int = 0
	var slot: int = 0
	var x: float = 130.0
	var y: float = 340.0
	var ty: float = 340.0
	var vy: float = 0.0
	var rot: float = 0.0
	var alive: bool = true
	var landed: bool = false
	var local: bool = true
	var connected: bool = true
	var score: int = 0
	var lives: int = 1
	var invuln: float = 0.0
	var anim: float = 0.0
	var flap_t: float = 0.0
	var died_at: float = 0.0

var mode: String = "classic"
var state: int = State.READY
var birds: Array = []
var bird_by_token: Dictionary = {}
var pipes: Array = []
var coins: Array = []
var fx: Array = []
var scroll: float = 0.0
var world_t: float = 0.0
var vis_t: float = 0.0
var speed: float = 165.0
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var next_pipe_idx: int = 0
var next_pipe_wx: float = 0.0
var night: float = 0.0
var night_target: float = 0.0
var shake: float = 0.0
var session_coins: int = 0
var crashes: int = 0
var countdown: float = 3.0
var last_count: int = 4
var end_timer: float = 0.0
var over_shown: bool = false
var state_timer: float = 0.0
var board_timer: float = 0.0
var _off: Vector2 = Vector2.ZERO

# mode configuration
var base_speed: float = 165.0
var gap0: float = 195.0
var gap_min: float = 150.0
var gap_step: float = 1.0
var move_start: int = 9999
var move_max: float = 0.0
var ramp: bool = true
var lives_start: int = 1
var is_practice: bool = false
var is_multi: bool = false
var is_lan: bool = false
var is_2p: bool = false
var target_score: int = 0
var level_def: Dictionary = {}

# HUD
var hud_root: Control
var score_label: Label
var sub_label: Label
var msg_label: Label
var coin_label: Label
var board_label: Label
var net_label: Label
var fps_label: Label
var pause_btn: TextureButton
var hearts_box: HBoxContainer
var overlay: CanvasLayer = null

func _ready() -> void:
	mode = Save.current_mode
	is_lan = mode == "lan"
	is_2p = mode == "local2p"
	is_multi = is_lan or is_2p
	is_practice = mode == "practice"
	_configure_mode()
	if is_lan:
		rng.seed = Net.match_seed
	else:
		rng.randomize()
	_create_birds()
	_build_hud()
	_update_daynight(true)
	next_pipe_wx = BIRD_X + 560.0
	Audio.play_music()
	_refresh_hud()
	if is_lan:
		Net.go.connect(_on_net_go)
		Net.remote_state.connect(_on_remote_state)
		Net.player_died.connect(_on_player_died)
		Net.match_over.connect(_on_match_over)
		Net.players_changed.connect(_on_players_changed)
		Net.connection_lost.connect(func(): net_label.text = "Connection lost - reconnecting...")
		Net.reconnecting.connect(func(a: int, m: int): net_label.text = "Reconnecting (%d/%d)..." % [a, m])
		Net.reconnected.connect(_on_reconnected)
		Net.host_lost.connect(_on_host_lost)
		Net.returned_to_lobby.connect(func(): Transition.go("res://scenes/lobby.tscn"))
		msg_label.text = "WAITING FOR PLAYERS..."
		if Net.go_received:
			_on_net_go()
		else:
			Net.report_loaded()

func _configure_mode() -> void:
	match mode:
		"classic":
			base_speed = 165.0
			gap0 = 195.0
			gap_min = 150.0
			gap_step = 1.0
			ramp = true
		"endless":
			base_speed = 170.0
			gap0 = 200.0
			gap_min = 135.0
			gap_step = 1.2
			ramp = true
			lives_start = 3
			move_start = 6
			move_max = 60.0
		"challenge":
			level_def = Save.CHALLENGE_LEVELS[clampi(Save.current_level, 0, Save.CHALLENGE_LEVELS.size() - 1)]
			base_speed = float(level_def["speed"])
			gap0 = float(level_def["gap"])
			gap_min = gap0
			gap_step = 0.0
			ramp = false
			target_score = int(level_def["target"])
			if float(level_def["move"]) > 0.0:
				move_start = 0
				move_max = float(level_def["move"])
		"practice":
			base_speed = 130.0
			gap0 = 245.0
			gap_min = 245.0
			gap_step = 0.0
			ramp = false
		_:  # local2p and lan share the same deterministic ruleset
			base_speed = 170.0
			gap0 = 205.0
			gap_min = 150.0
			gap_step = 1.5
			ramp = false
			move_start = 12
			move_max = 40.0

func _new_bird(pname: String, skin: int) -> Bird:
	var b: Bird = Bird.new()
	b.pname = pname
	b.skin = skin
	b.lives = lives_start
	return b

func _create_birds() -> void:
	birds.clear()
	bird_by_token.clear()
	if is_lan:
		var tokens: Array = Net.players.keys()
		tokens.sort()
		var local_b: Bird = null
		var others: Array = []
		for t in tokens:
			var p: Dictionary = Net.players[t]
			var b: Bird = _new_bird(str(p["name"]), int(p["skin"]))
			b.token = str(t)
			b.local = (t == Net.my_token)
			b.connected = bool(p["connected"])
			bird_by_token[t] = b
			if b.local:
				local_b = b
			else:
				others.append(b)
		if local_b == null:
			local_b = _new_bird(Save.player_name, Save.skin)
		birds.append(local_b)
		birds.append_array(others)
	elif is_2p:
		var b1: Bird = _new_bird("P1", Save.skin)
		var b2: Bird = _new_bird("P2", (Save.skin + 1) % Save.SKIN_NAMES.size())
		b2.x = BIRD_X + 40.0
		birds.append(b1)
		birds.append(b2)
	else:
		birds.append(_new_bird(Save.player_name, Save.skin))
	for i in range(birds.size()):
		birds[i].slot = i

# ------------------------------------------------------------------ HUD
func _build_hud() -> void:
	var hud: CanvasLayer = CanvasLayer.new()
	hud.layer = 10
	add_child(hud)
	hud_root = Control.new()
	hud_root.theme = UI.theme()
	hud_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(hud_root)
	var m: Dictionary = UI.safe_margins()
	var top: float = 14.0 + float(m["top"])
	var lx: float = 14.0 + float(m["left"])
	var rx: float = 14.0 + float(m["right"])

	score_label = _wide_label("0", 72, 12, top + 40.0, top + 140.0)
	sub_label = _wide_label("", 20, 5, top + 140.0, top + 200.0)
	msg_label = _wide_label("", 36, 9, 290.0, 420.0)
	net_label = _wide_label("", 20, 5, top + 200.0, top + 270.0)
	for wl in [sub_label, msg_label, net_label]:
		wl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	net_label.add_theme_color_override("font_color", Color(1.0, 0.8, 0.4))

	var cb: HBoxContainer = HBoxContainer.new()
	cb.position = Vector2(lx, top)
	cb.add_theme_constant_override("separation", 6)
	var ci: TextureRect = TextureRect.new()
	ci.texture = Assets.tex("icon_coin")
	ci.custom_minimum_size = Vector2(34, 34)
	ci.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	cb.add_child(ci)
	coin_label = UI.label("0", 28, Color(1, 0.9, 0.3), 6)
	cb.add_child(coin_label)
	hud_root.add_child(cb)

	hearts_box = HBoxContainer.new()
	hearts_box.position = Vector2(lx, top + 44.0)
	hearts_box.add_theme_constant_override("separation", 2)
	hud_root.add_child(hearts_box)

	board_label = UI.label("", 18, Color.WHITE, 5)
	board_label.position = Vector2(lx, top + 44.0)
	board_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	hud_root.add_child(board_label)

	fps_label = UI.label("", 16, Color.WHITE, 4)
	fps_label.position = Vector2(lx, 770.0)
	fps_label.visible = Save.show_fps
	hud_root.add_child(fps_label)

	pause_btn = TextureButton.new()
	pause_btn.texture_normal = Assets.tex("icon_pause")
	pause_btn.ignore_texture_size = true
	pause_btn.stretch_mode = TextureButton.STRETCH_KEEP_ASPECT_CENTERED
	pause_btn.focus_mode = Control.FOCUS_NONE
	pause_btn.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	pause_btn.offset_left = -(64.0 + rx)
	pause_btn.offset_right = -rx
	pause_btn.offset_top = top
	pause_btn.offset_bottom = top + 64.0
	pause_btn.pressed.connect(_on_pause_pressed)
	hud_root.add_child(pause_btn)

func _wide_label(text: String, size: int, outline: int, top_off: float, bottom_off: float) -> Label:
	var l: Label = UI.label(text, size, Color.WHITE, outline)
	l.set_anchors_preset(Control.PRESET_TOP_WIDE)
	l.offset_top = top_off
	l.offset_bottom = bottom_off
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_root.add_child(l)
	return l

func _refresh_hud() -> void:
	if is_2p:
		score_label.text = "%d  -  %d" % [birds[0].score, birds[1].score]
		score_label.add_theme_font_size_override("font_size", 56)
		msg_label.text = "P1: tap LEFT\nP2: tap RIGHT"
		msg_label.add_theme_font_size_override("font_size", 24)
	elif not is_lan:
		score_label.text = str(birds[0].score)
		msg_label.text = "TAP TO START"
	else:
		score_label.text = str(birds[0].score)
	coin_label.text = str(Save.coins + session_coins)
	match mode:
		"challenge":
			sub_label.text = "Level %d: %s - reach %d" % [Save.current_level + 1, level_def["title"], target_score]
		"practice":
			sub_label.text = "PRACTICE - crashes: %d" % crashes
		"endless":
			sub_label.text = "ENDLESS"
		_:
			sub_label.text = ""
	_update_hearts()
	if is_lan:
		_update_board()

func _update_hearts() -> void:
	UI.clear(hearts_box)
	if lives_start <= 1 or is_multi or birds.is_empty():
		return
	for i in range(birds[0].lives):
		var h: TextureRect = TextureRect.new()
		h.texture = Assets.tex("icon_heart")
		h.custom_minimum_size = Vector2(32, 32)
		h.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		hearts_box.add_child(h)

func _update_board() -> void:
	var lines: Array = []
	for b in birds:
		var tag: String = "%s: %d" % [b.pname, b.score]
		if not b.alive:
			tag += "  (out)"
		elif not b.connected:
			tag += "  (offline)"
		lines.append(tag)
	board_label.text = "\n".join(lines)

# ------------------------------------------------------------------ input
func _input(event: InputEvent) -> void:
	if get_tree().paused or overlay != null:
		return
	if event is InputEventScreenTouch and event.pressed:
		_handle_tap(event.position)
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT and not OS.has_feature("mobile"):
		_handle_tap(event.position)
	elif event is InputEventKey and event.pressed and not event.echo:
		match event.physical_keycode:
			KEY_SPACE, KEY_W:
				_flap(0)
			KEY_UP, KEY_ENTER, KEY_KP_ENTER:
				_flap(1 if is_2p else 0)
			KEY_ESCAPE, KEY_P:
				_on_pause_pressed()

func _handle_tap(pos: Vector2) -> void:
	if pause_btn.get_global_rect().has_point(pos):
		return
	var idx: int = 0
	if is_2p and pos.x >= get_viewport_rect().size.x * 0.5:
		idx = 1
	_flap(idx)

func _flap(idx: int) -> void:
	if idx >= birds.size() or over_shown:
		return
	var b: Bird = birds[idx]
	match state:
		State.READY:
			if not is_lan:
				_begin_play()
				_do_flap(b)
		State.PLAYING:
			if b.alive and b.local:
				_do_flap(b)

func _do_flap(b: Bird) -> void:
	b.vy = FLAP_V
	b.flap_t = 0.3
	Audio.play("flap", randf_range(0.97, 1.05))
	_burst(Vector2(b.x - 18.0, b.y + 8.0), Color(1, 1, 1, 0.9), 4, 30.0, 70.0, 0.35, 120.0, 40.0, Vector2(-0.4, 1.0))

# ------------------------------------------------------------------ state flow
func _begin_play() -> void:
	state = State.PLAYING
	msg_label.text = ""
	msg_label.modulate.a = 1.0
	world_t = 0.0
	scroll = 0.0
	for b in birds:
		b.vy = FLAP_V * 0.9
		b.flap_t = 0.3

func _on_net_go() -> void:
	if state == State.READY:
		state = State.COUNTDOWN
		countdown = 3.0
		last_count = 4

func _process(delta: float) -> void:
	delta = minf(delta, 1.0 / 30.0)
	vis_t += delta
	night = move_toward(night, night_target, delta * 0.5)
	if shake > 0.0:
		shake = maxf(0.0, shake - delta * 40.0)
	_update_fx(delta)
	var vw: float = get_viewport_rect().size.x
	match state:
		State.READY:
			_idle(delta)
			if not is_lan:
				msg_label.modulate.a = 0.6 + 0.4 * sin(vis_t * 5.0)
		State.COUNTDOWN:
			_idle(delta)
			countdown -= delta
			var n: int = ceili(countdown)
			if n != last_count:
				last_count = n
				if n > 0:
					msg_label.text = str(n)
					Audio.play("countdown")
				else:
					Audio.play("swoosh")
			if countdown <= 0.0:
				_begin_play()
				msg_label.text = "GO!"
				get_tree().create_timer(0.6).timeout.connect(func():
					if state == State.PLAYING and msg_label.text == "GO!":
						msg_label.text = "")
		State.PLAYING:
			_update_play(delta, vw)
		State.ENDED:
			_update_ended(delta)
	if is_lan:
		board_timer += delta
		if board_timer > 0.25:
			board_timer = 0.0
			_update_board()
	if Save.show_fps:
		fps_label.text = "%d FPS" % Engine.get_frames_per_second()
	queue_redraw()

func _idle(delta: float) -> void:
	for b in birds:
		b.anim += delta
		b.y = 340.0 + sin(vis_t * 5.0 + float(b.slot)) * 8.0
		b.rot = 0.0

func _update_play(delta: float, vw: float) -> void:
	world_t += delta
	var lead: int = 0
	for b in birds:
		lead = maxi(lead, b.score)
	speed = (base_speed + minf(float(lead) * 3.0, 95.0)) if ramp else base_speed
	scroll += speed * delta
	_spawn_pipes(vw)
	for b in birds:
		if b.local:
			_step_local(b, delta)
		else:
			_step_remote(b, delta)
	if is_lan and birds[0].alive:
		state_timer += delta
		if state_timer >= 1.0 / Net.STATE_HZ:
			state_timer = 0.0
			Net.send_state(birds[0].y, birds[0].vy, birds[0].score, true)

func _update_ended(delta: float) -> void:
	end_timer += delta
	for b in birds:
		b.anim += delta
		if not b.alive:
			_dead_physics(b, delta)
	if end_timer > 0.8 and not over_shown:
		_show_end_screen()

# ------------------------------------------------------------------ world
func _spawn_pipes(vw: float) -> void:
	while next_pipe_wx < scroll + vw + 240.0:
		_spawn_pipe()
	while pipes.size() > 0 and float(pipes[0]["wx"]) - scroll < -140.0:
		pipes.pop_front()
	while coins.size() > 0 and float(coins[0]["wx"]) - scroll < -140.0:
		coins.pop_front()

func _spawn_pipe() -> void:
	var i: int = next_pipe_idx
	var gap: float = maxf(gap_min, gap0 - gap_step * float(i))
	var amp: float = 0.0
	if i >= move_start and move_max > 0.0:
		amp = minf(move_max, 8.0 + float(i - move_start) * 6.0)
	var margin: float = 64.0
	var lo: float = margin + gap * 0.5 + amp
	var hi: float = PLAY_H - margin - gap * 0.5 - amp
	var cy: float = rng.randf_range(lo, hi)
	var ph: float = rng.randf() * TAU
	var p: Dictionary = {"i": i, "wx": next_pipe_wx, "cy": cy, "gap": gap, "amp": amp, "ph": ph, "scored": {}}
	pipes.append(p)
	if i % 3 == 1 and not is_practice:
		coins.append({"wx": next_pipe_wx, "pipe": p, "taken": false})
	next_pipe_idx += 1
	next_pipe_wx += PIPE_SPACING

func _pipe_cy(p: Dictionary) -> float:
	return float(p["cy"]) + sin(world_t * 1.6 + float(p["ph"])) * float(p["amp"])

static func _circle_rect(cx: float, cy: float, r: float, rx: float, ry: float, rw: float, rh: float) -> bool:
	var nx: float = clampf(cx, rx, rx + rw)
	var ny: float = clampf(cy, ry, ry + rh)
	var dx: float = cx - nx
	var dy: float = cy - ny
	return dx * dx + dy * dy < r * r

func _hits_pipe(b: Bird) -> bool:
	var hw: float = PIPE_W * 0.5
	for p in pipes:
		var sx: float = float(p["wx"]) - scroll
		if absf(sx - b.x) > hw + BIRD_R + 4.0:
			continue
		var cy: float = _pipe_cy(p)
		var top: float = cy - float(p["gap"]) * 0.5
		var bot: float = cy + float(p["gap"]) * 0.5
		if _circle_rect(b.x, b.y, BIRD_R - 2.0, sx - hw, -200.0, PIPE_W, top + 200.0):
			return true
		if _circle_rect(b.x, b.y, BIRD_R - 2.0, sx - hw, bot, PIPE_W, PLAY_H - bot + 100.0):
			return true
	return false

func _safe_y(b: Bird) -> float:
	var best_d: float = 99999.0
	var y: float = 340.0
	for p in pipes:
		var sx: float = float(p["wx"]) - scroll
		if sx > b.x - 70.0 and sx - b.x < best_d:
			best_d = sx - b.x
			y = _pipe_cy(p)
	return y

func _step_local(b: Bird, delta: float) -> void:
	b.anim += delta
	b.flap_t = maxf(0.0, b.flap_t - delta)
	if not b.alive:
		_dead_physics(b, delta)
		return
	b.vy = minf(b.vy + GRAVITY * delta, MAX_FALL)
	b.y += b.vy * delta
	b.rot = clampf(b.vy / 650.0, -0.5, 1.3)
	if b.y < BIRD_R:
		b.y = BIRD_R
		b.vy = maxf(b.vy, 0.0)
	if b.invuln > 0.0:
		b.invuln -= delta
	if b.y > PLAY_H - BIRD_R:
		b.y = PLAY_H - BIRD_R
		_bird_hit(b, true)
	elif b.invuln <= 0.0 and _hits_pipe(b):
		_bird_hit(b, false)
	if b.alive and state == State.PLAYING:
		_score_and_coins(b)

func _step_remote(b: Bird, delta: float) -> void:
	b.anim += delta
	b.flap_t = maxf(0.0, b.flap_t - delta)
	if not b.alive:
		_dead_physics(b, delta)
		return
	b.vy = minf(b.vy + GRAVITY * delta, MAX_FALL)
	b.ty = clampf(b.ty + b.vy * delta, BIRD_R, PLAY_H - BIRD_R)
	b.y = lerpf(b.y, b.ty, clampf(delta * 18.0, 0.0, 1.0))
	b.rot = clampf(b.vy / 650.0, -0.5, 1.3)

func _dead_physics(b: Bird, delta: float) -> void:
	if not b.landed:
		b.vy = minf(b.vy + GRAVITY * delta, MAX_FALL)
		b.y += b.vy * delta
		b.rot = minf(b.rot + delta * 6.0, 1.5)
		if b.y >= PLAY_H - BIRD_R:
			b.y = PLAY_H - BIRD_R
			b.landed = true
			b.vy = 0.0
	elif state == State.PLAYING and is_multi:
		b.x -= speed * delta

func _score_and_coins(b: Bird) -> void:
	for p in pipes:
		var sx: float = float(p["wx"]) - scroll
		if sx < b.x - 4.0 and not p["scored"].has(b.slot):
			p["scored"][b.slot] = true
			b.score += 1
			_on_score(b)
			if not b.alive or state != State.PLAYING:
				return
	for c in coins:
		if c["taken"]:
			continue
		var sx2: float = float(c["wx"]) - scroll
		if absf(sx2 - b.x) > 40.0:
			continue
		var cy: float = _pipe_cy(c["pipe"])
		if Vector2(sx2 - b.x, cy - b.y).length() < BIRD_R + 16.0:
			c["taken"] = true
			session_coins += 1
			coin_label.text = str(Save.coins + session_coins)
			Audio.play("coin")
			_burst(Vector2(sx2, cy), Color(1, 0.85, 0.2), 8, 60.0, 140.0, 0.45, 200.0, 180.0, Vector2.UP)

func _on_score(b: Bird) -> void:
	Audio.play("score")
	if is_2p:
		score_label.text = "%d  -  %d" % [birds[0].score, birds[1].score]
	else:
		score_label.text = str(birds[0].score)
	_burst(Vector2(b.x, b.y - 20.0), Color(1, 0.95, 0.5), 6, 40.0, 100.0, 0.5, 150.0, 180.0, Vector2.UP)
	_update_daynight()
	if mode == "challenge" and b.score >= target_score:
		_level_complete()

func _update_daynight(instant: bool = false) -> void:
	var target: float = 0.0
	match Save.bg_mode:
		1:
			target = 0.0
		2:
			target = 1.0
		_:
			if mode == "challenge":
				target = 1.0 if bool(level_def.get("night", false)) else 0.0
			elif is_lan:
				target = float(Net.match_seed % 2)
			else:
				var lead: int = 0
				for b in birds:
					lead = maxi(lead, b.score)
				target = float(int(lead / 15) % 2)
	night_target = target
	if instant:
		night = target

func _bird_hit(b: Bird, ground: bool) -> void:
	if ground and b.invuln > 0.0:
		b.vy = -380.0
		return
	if is_practice:
		crashes += 1
		sub_label.text = "PRACTICE - crashes: %d" % crashes
		b.invuln = 1.4
		b.vy = -420.0
		shake = 6.0
		Audio.play("hit")
		if not ground:
			b.y = _safe_y(b)
		return
	b.lives -= 1
	shake = 12.0
	Audio.play("hit")
	if Save.vibrate:
		Input.vibrate_handheld(70)
	fx.append({"x": b.x, "y": b.y, "t": 0.0})
	if b.lives > 0:
		b.invuln = 1.8
		b.vy = -300.0
		b.y = _safe_y(b)
		_burst(Vector2(b.x, b.y), Color(1, 0.4, 0.4), 12, 80.0, 200.0, 0.5, 300.0, 180.0, Vector2.UP)
		_update_hearts()
		return
	b.alive = false
	b.vy = -300.0
	b.died_at = world_t
	Audio.play("die")
	_burst(Vector2(b.x, b.y), _skin_color(b.skin), 16, 80.0, 240.0, 0.7, 400.0, 180.0, Vector2.UP)
	_on_bird_died(b)

func _on_bird_died(b: Bird) -> void:
	_update_hearts()
	if is_lan:
		if b.local:
			msg_label.text = "OUT! Waiting for others..."
			msg_label.add_theme_font_size_override("font_size", 28)
			Net.send_dead(b.score)
			Net.send_state(b.y, b.vy, b.score, false)
		return
	if is_2p:
		for x in birds:
			if x.alive:
				return
	state = State.ENDED
	end_timer = 0.0

# ------------------------------------------------------------------ LAN callbacks
func _on_remote_state(tok: String, y: float, vy: float, score: int, alive: bool) -> void:
	if not bird_by_token.has(tok):
		return
	var b: Bird = bird_by_token[tok]
	if b.local:
		return
	if vy < b.vy - 250.0:
		b.flap_t = 0.3
	b.ty = y
	b.vy = vy
	b.score = score
	if not alive and b.alive:
		b.alive = false

func _on_player_died(tok: String, score: int) -> void:
	if not bird_by_token.has(tok):
		return
	var b: Bird = bird_by_token[tok]
	b.score = score
	if b.local:
		return
	if b.alive:
		b.alive = false
		_burst(Vector2(b.x, b.y), _skin_color(b.skin), 12, 80.0, 200.0, 0.6, 400.0, 180.0, Vector2.UP)
		fx.append({"x": b.x, "y": b.y, "t": 0.0})
	_update_board()

func _on_players_changed() -> void:
	for t in bird_by_token:
		if Net.players.has(t):
			bird_by_token[t].connected = bool(Net.players[t]["connected"])

func _on_reconnected() -> void:
	net_label.text = ""
	if not birds[0].alive:
		Net.send_dead(birds[0].score)

func _on_host_lost() -> void:
	if over_shown:
		return
	state = State.ENDED
	over_shown = true
	_show_panel("HOST LEFT", [["The match was closed.", 20, Color.WHITE], ["Your score: %d" % birds[0].score, 24, Color(1, 0.9, 0.3)]],
		[["MENU", "ButtonRed", _to_menu]])

func _on_match_over(results: Array) -> void:
	state = State.ENDED
	over_shown = true
	var my_rank: int = 1
	var my_score: int = birds[0].score
	var rows: Array = []
	for i in range(results.size()):
		var r: Dictionary = results[i]
		var mine: bool = r["token"] == Net.my_token
		if mine:
			my_rank = i + 1
			my_score = int(r["score"])
		rows.append(["%d. %s  %d" % [i + 1, r["name"], r["score"]], 22 if mine else 20, Color(1, 0.9, 0.3) if mine else Color.WHITE])
	var winner: bool = my_rank == 1 and results.size() >= 2
	var reward: int = my_score + (10 if winner else 0) + session_coins
	Save.record_score("lan", my_score)
	Save.add_coins(reward)
	Audio.play("win" if winner else "die")
	rows.append(["+%d coins" % reward, 22, Color(1, 0.9, 0.3)])
	var buttons: Array = []
	if Net.is_host:
		buttons.append(["BACK TO LOBBY", "ButtonGreen", func(): Net.return_to_lobby()])
	else:
		rows.append(["Waiting for host...", 16, Color(1, 0.85, 0.5)])
	buttons.append(["LEAVE ROOM", "ButtonRed", _leave_lan])
	_show_panel("YOU WIN!" if winner else "RESULTS", rows, buttons)

func _leave_lan() -> void:
	Net.leave()
	Transition.go("res://scenes/main_menu.tscn")

# ------------------------------------------------------------------ end screens
func _show_end_screen() -> void:
	over_shown = true
	if is_2p:
		_show_2p_result()
		return
	var score: int = birds[0].score
	if mode == "challenge":
		Save.add_coins(session_coins)
		Save.record_score("challenge", score)
		_show_panel("LEVEL FAILED", [["Score %d / %d" % [score, target_score], 28, Color.WHITE], ["+%d coins" % session_coins, 22, Color(1, 0.9, 0.3)]],
			[["RETRY", "ButtonGreen", _restart], ["MENU", "ButtonRed", _to_menu]])
		return
	var is_best: bool = Save.record_score(mode, score)
	var medal: int = Save.medal_for(score)
	var total: int = session_coins + Save.medal_bonus(medal)
	Save.add_coins(total)
	var rows: Array = []
	if medal > 0:
		rows.append(Assets.tex("medal_" + Save.medal_name(medal)))
	rows.append(["Score  %d" % score, 32, Color.WHITE])
	rows.append(["Best  %d%s" % [Save.best(mode), "  NEW!" if is_best else ""], 24, Color(1, 0.9, 0.3)])
	rows.append(["+%d coins" % total, 22, Color(1, 0.9, 0.3)])
	if is_best:
		Audio.play("win")
	_show_panel("GAME OVER", rows, [["RESTART", "ButtonGreen", _restart], ["MENU", "ButtonRed", _to_menu]])

func _show_2p_result() -> void:
	var a: Bird = birds[0]
	var b: Bird = birds[1]
	var title: String = "DRAW!"
	if a.score > b.score or (a.score == b.score and a.died_at > b.died_at):
		title = "P1 WINS!"
	elif b.score > a.score or (a.score == b.score and b.died_at > a.died_at):
		title = "P2 WINS!"
	Save.record_score("local2p", maxi(a.score, b.score))
	Save.add_coins(session_coins)
	Audio.play("win")
	_show_panel(title, [["P1  %d" % a.score, 30, Color.WHITE], ["P2  %d" % b.score, 30, Color.WHITE], ["+%d coins" % session_coins, 22, Color(1, 0.9, 0.3)]],
		[["REMATCH", "ButtonGreen", _restart], ["MENU", "ButtonRed", _to_menu]])

func _level_complete() -> void:
	if over_shown:
		return
	state = State.ENDED
	over_shown = true
	var lv: int = Save.current_level
	var first: bool = lv >= int(Save.data["challenge_done"])
	var reward: int = (10 + lv * 5) if first else 3
	if first:
		Save.data["challenge_done"] = lv + 1
	Save.add_coins(reward + session_coins)
	Audio.play("win")
	var buttons: Array = []
	if lv + 1 < Save.CHALLENGE_LEVELS.size():
		buttons.append(["NEXT LEVEL", "ButtonGreen", _next_level])
	buttons.append(["REPLAY", "Button", _restart])
	buttons.append(["MENU", "ButtonRed", _to_menu])
	_show_panel("LEVEL COMPLETE!", [["%s" % level_def["title"], 24, Color.WHITE], ["+%d coins" % (reward + session_coins), 24, Color(1, 0.9, 0.3)]], buttons)

func _next_level() -> void:
	Save.current_level += 1
	_restart()

func _restart() -> void:
	get_tree().paused = false
	Transition.go("res://scenes/game.tscn")

func _to_menu() -> void:
	get_tree().paused = false
	if is_lan:
		Net.leave()
	Transition.go("res://scenes/main_menu.tscn")

# ------------------------------------------------------------------ pause / overlays
func _on_pause_pressed() -> void:
	if over_shown or overlay != null:
		return
	Audio.play("click")
	_open_pause()

func _open_pause() -> void:
	if overlay != null or over_shown:
		return
	if is_lan:
		_show_panel("LEAVE MATCH?", [["You will forfeit this match.", 20, Color.WHITE]],
			[["CONTINUE", "ButtonGreen", _close_overlay], ["LEAVE", "ButtonRed", _leave_lan]])
	else:
		get_tree().paused = true
		_show_panel("PAUSED", [], [["RESUME", "ButtonGreen", _resume], ["RESTART", "Button", _restart], ["MENU", "ButtonRed", _to_menu]])

func _resume() -> void:
	get_tree().paused = false
	_close_overlay()

func _close_overlay() -> void:
	if overlay != null:
		overlay.queue_free()
		overlay = null

func _show_panel(title: String, rows: Array, buttons: Array) -> void:
	_close_overlay()
	overlay = CanvasLayer.new()
	overlay.layer = 20
	overlay.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(overlay)
	var root: Control = Control.new()
	root.theme = UI.theme()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(root)
	var dim: ColorRect = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.5)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(dim)
	var center: CenterContainer = CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	var panel: PanelContainer = PanelContainer.new()
	center.add_child(panel)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	vb.custom_minimum_size = Vector2(290, 0)
	panel.add_child(vb)
	vb.add_child(UI.label(title, 34, Color(1.0, 0.86, 0.2), 8))
	for r in rows:
		if r is Texture2D:
			var tr: TextureRect = TextureRect.new()
			tr.texture = r
			tr.custom_minimum_size = Vector2(64, 64)
			tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			vb.add_child(tr)
		else:
			vb.add_child(UI.label(str(r[0]), int(r[1]), r[2], 4))
	for bd in buttons:
		var btn: Button = UI.button(str(bd[0]), str(bd[1]), Vector2(260, 56))
		btn.pressed.connect(bd[2])
		vb.add_child(btn)
	root.modulate.a = 0.0
	var tw: Tween = root.create_tween()
	tw.tween_property(root, "modulate:a", 1.0, 0.2)

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		if not is_lan and state == State.PLAYING and overlay == null:
			_open_pause()
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if overlay != null:
			if over_shown:
				_to_menu()
			elif get_tree().paused:
				_resume()
			else:
				_close_overlay()
		elif over_shown:
			_to_menu()
		else:
			_open_pause()

# ------------------------------------------------------------------ effects
func _burst(pos: Vector2, color: Color, amount: int, vmin: float, vmax: float, life: float, grav: float, spread: float, dir: Vector2) -> void:
	if Save.low_quality:
		amount = int(amount / 3)
	if amount <= 0:
		return
	var p: CPUParticles2D = CPUParticles2D.new()
	p.texture = Assets.tex("particle")
	p.position = pos
	p.amount = amount
	p.one_shot = true
	p.explosiveness = 1.0
	p.lifetime = life
	p.direction = dir
	p.spread = spread
	p.initial_velocity_min = vmin
	p.initial_velocity_max = vmax
	p.gravity = Vector2(0.0, grav)
	p.scale_amount_min = 0.3
	p.scale_amount_max = 0.8
	p.color = color
	var g: Gradient = Gradient.new()
	g.set_color(0, Color(1, 1, 1, 1))
	g.set_color(1, Color(1, 1, 1, 0))
	p.color_ramp = g
	add_child(p)
	p.emitting = true
	get_tree().create_timer(life + 0.4).timeout.connect(p.queue_free)

func _update_fx(delta: float) -> void:
	for f in fx:
		f["t"] = float(f["t"]) + delta
	while fx.size() > 0 and float(fx[0]["t"]) > 0.35:
		fx.pop_front()

# ------------------------------------------------------------------ drawing
func _draw() -> void:
	var w: float = get_viewport_rect().size.x
	_off = Vector2.ZERO
	if shake > 0.0:
		_off = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * minf(shake, 10.0)
	draw_set_transform(_off, 0.0, Vector2.ONE)
	Scenery.draw_back(self, w, WORLD_H, scroll, night, GROUND_H, Save.low_quality)
	_draw_pipes(w)
	_draw_coins(w)
	Scenery.draw_ground(self, w, WORLD_H, scroll, GROUND_H, night)
	if is_2p and state == State.READY:
		for y in range(0, int(PLAY_H), 28):
			draw_rect(Rect2(w * 0.5 - 1.5, float(y), 3.0, 14.0), Color(1, 1, 1, 0.35))
	for i in range(birds.size() - 1, -1, -1):
		_draw_bird(birds[i])
	for f in fx:
		var t: Texture2D = Assets.tex("puff_%d" % mini(5, int(float(f["t"]) * 18.0)))
		draw_texture(t, Vector2(float(f["x"]), float(f["y"])) - t.get_size() * 0.5)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func _draw_pipes(w: float) -> void:
	var body: Texture2D = Assets.tex("pipe_body")
	var cap: Texture2D = Assets.tex("pipe_cap")
	var tint: Color = Color(1.0 - 0.22 * night, 1.0 - 0.1 * night, 1.0, 1.0)
	for p in pipes:
		var sx: float = float(p["wx"]) - scroll
		if sx < -90.0 or sx > w + 90.0:
			continue
		var cy: float = _pipe_cy(p)
		var top: float = cy - float(p["gap"]) * 0.5
		var bot: float = cy + float(p["gap"]) * 0.5
		var bx: float = sx - 36.0
		if top - CAP_H > -30.0:
			draw_texture_rect(body, Rect2(bx, -30.0, 72.0, top - CAP_H + 30.0), true, tint)
		draw_texture_rect(cap, Rect2(sx - 40.0, top - CAP_H, 80.0, CAP_H), false, tint)
		draw_texture_rect(cap, Rect2(sx - 40.0, bot, 80.0, CAP_H), false, tint)
		draw_texture_rect(body, Rect2(bx, bot + CAP_H, 72.0, PLAY_H - bot - CAP_H + 12.0), true, tint)

func _draw_coins(w: float) -> void:
	var frame: int = int(vis_t * 10.0) % 4
	var t: Texture2D = Assets.tex("coin_%d" % frame)
	for c in coins:
		if c["taken"]:
			continue
		var sx: float = float(c["wx"]) - scroll
		if sx < -30.0 or sx > w + 30.0:
			continue
		draw_texture(t, Vector2(sx, _pipe_cy(c["pipe"])) - t.get_size() * 0.5)

func _draw_bird(b: Bird) -> void:
	var seq: Array = [0, 1, 2, 1]
	var f: int = 1
	if state == State.READY or state == State.COUNTDOWN:
		f = seq[int(b.anim * 10.0) % 4]
	elif b.alive and b.flap_t > 0.0:
		f = seq[int((0.3 - b.flap_t) * 16.0) % 4]
	var tex: Texture2D = Assets.bird(b.skin, f)
	var alpha: float = 1.0
	if not b.local:
		alpha = 0.55
		if not b.connected:
			alpha = 0.25
	if b.invuln > 0.0 and int(vis_t * 12.0) % 2 == 0:
		alpha *= 0.4
	draw_set_transform(Vector2(b.x, b.y) + _off, b.rot, Vector2.ONE)
	draw_texture(tex, -tex.get_size() * 0.5, Color(1, 1, 1, alpha))
	draw_set_transform(_off, 0.0, Vector2.ONE)
	if is_lan and b.alive:
		var font: Font = UI.font()
		var tag: String = b.pname if b.connected else b.pname + " ?"
		var pos: Vector2 = Vector2(b.x - 60.0, b.y - 28.0)
		draw_string_outline(font, pos, tag, HORIZONTAL_ALIGNMENT_CENTER, 120.0, 16, 5, Color(0.1, 0.1, 0.2, alpha))
		draw_string(font, pos, tag, HORIZONTAL_ALIGNMENT_CENTER, 120.0, 16, Color(1, 1, 1, maxf(alpha, 0.6)))
	elif is_2p and state == State.READY:
		var font2: Font = UI.font()
		draw_string_outline(font2, Vector2(b.x - 30.0, b.y - 30.0), b.pname, HORIZONTAL_ALIGNMENT_CENTER, 60.0, 18, 5, Color(0.1, 0.1, 0.2, 1))
		draw_string(font2, Vector2(b.x - 30.0, b.y - 30.0), b.pname, HORIZONTAL_ALIGNMENT_CENTER, 60.0, 18, Color.WHITE)

# Dominant colour for each skin (particle tint)
const SKIN_COLORS: Array = [Color(1, 0.84, 0.2), Color(0.9, 0.27, 0.3), Color(0.34, 0.69, 0.95), Color(0.36, 0.83, 0.52), Color(0.68, 0.44, 0.91), Color(1, 0.75, 0.1)]

func _skin_color(skin: int) -> Color:
	return SKIN_COLORS[clampi(skin, 0, SKIN_COLORS.size() - 1)]
