extends RefCounted
## Shared UI helpers: theme, buttons, labels, screen scaffolding.

const Assets = preload("res://scripts/assets.gd")
const ScenicBG = preload("res://scripts/scenic_bg.gd")

static var _theme: Theme = null
static var _font: Font = null

static func font() -> Font:
	if _font == null:
		var p: String = "res://assets/fonts/game_font.ttf"
		if ResourceLoader.exists(p):
			_font = load(p)
		else:
			_font = ThemeDB.fallback_font
	return _font

static func _sb(tex_name: String, margin: int) -> StyleBoxTexture:
	var s: StyleBoxTexture = StyleBoxTexture.new()
	s.texture = Assets.tex(tex_name)
	s.texture_margin_left = margin
	s.texture_margin_right = margin
	s.texture_margin_top = margin
	s.texture_margin_bottom = margin
	s.content_margin_left = 16
	s.content_margin_right = 16
	s.content_margin_top = 8
	s.content_margin_bottom = 12
	return s

static func theme() -> Theme:
	if _theme != null:
		return _theme
	var t: Theme = Theme.new()
	t.default_font = font()
	t.default_font_size = 26
	var variants: Dictionary = {"Button": "blue", "ButtonGreen": "green", "ButtonRed": "red", "ButtonYellow": "yellow"}
	for key in variants:
		var c: String = variants[key]
		if key != "Button":
			t.set_type_variation(key, "Button")
		t.set_stylebox("normal", key, _sb("btn_%s" % c, 22))
		t.set_stylebox("hover", key, _sb("btn_%s" % c, 22))
		t.set_stylebox("pressed", key, _sb("btn_%s_down" % c, 22))
		t.set_stylebox("disabled", key, _sb("btn_gray", 22))
		t.set_stylebox("focus", key, StyleBoxEmpty.new())
		for col_name in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_disabled_color"]:
			t.set_color(col_name, key, Color.WHITE if col_name != "font_disabled_color" else Color(0.85, 0.85, 0.9))
		t.set_color("font_outline_color", key, Color(0, 0, 0, 0.45))
		t.set_constant("outline_size", key, 5)
		t.set_font_size("font_size", key, 28)
		t.set_font("font", key, font())
	t.set_stylebox("panel", "PanelContainer", _sb("panel", 24))
	var le: StyleBoxFlat = StyleBoxFlat.new()
	le.bg_color = Color(1, 1, 1, 0.95)
	le.set_corner_radius_all(12)
	le.content_margin_left = 14
	le.content_margin_right = 14
	le.content_margin_top = 10
	le.content_margin_bottom = 10
	t.set_stylebox("normal", "LineEdit", le)
	t.set_stylebox("focus", "LineEdit", le)
	t.set_color("font_color", "LineEdit", Color(0.1, 0.12, 0.2))
	t.set_color("font_placeholder_color", "LineEdit", Color(0.5, 0.52, 0.6))
	t.set_color("caret_color", "LineEdit", Color(0.1, 0.12, 0.2))
	t.set_font_size("font_size", "LineEdit", 26)
	t.set_font_size("font_size", "Label", 24)
	_theme = t
	return t

static func safe_margins() -> Dictionary:
	# Display-cutout / system-bar insets converted to canvas units.
	var res: Dictionary = {"top": 0.0, "left": 0.0, "right": 0.0, "bottom": 0.0}
	var scr: Vector2i = DisplayServer.screen_get_size()
	var sa: Rect2i = DisplayServer.get_display_safe_area()
	if scr.y > 0 and sa.size.x > 0 and OS.has_feature("mobile"):
		var k: float = 800.0 / float(scr.y)
		res["top"] = float(sa.position.y) * k
		res["left"] = float(sa.position.x) * k
		res["right"] = float(scr.x - sa.end.x) * k
		res["bottom"] = float(scr.y - sa.end.y) * k
	return res

static func label(text: String, size: int = 28, color: Color = Color.WHITE, outline: int = 6) -> Label:
	var l: Label = Label.new()
	l.text = text
	l.add_theme_font_override("font", font())
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0.12, 0.08, 0.2, 1))
	l.add_theme_constant_override("outline_size", outline)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l

## Label that wraps text inside a fixed width.
static func wrap_label(text: String, size: int, color: Color, width: float) -> Label:
	var l: Label = label(text, size, color, 4)
	l.custom_minimum_size = Vector2(width, 0)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

static func button(text: String, variant: String = "Button", min_size: Vector2 = Vector2(290, 64)) -> Button:
	var b: Button = Button.new()
	b.text = text
	b.theme_type_variation = variant
	b.custom_minimum_size = min_size
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(func(): Audio.play("click"))
	return b

static func spacer(h: float) -> Control:
	var c: Control = Control.new()
	c.custom_minimum_size = Vector2(0, h)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c

static func coin_bar() -> HBoxContainer:
	var hb: HBoxContainer = HBoxContainer.new()
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_theme_constant_override("separation", 8)
	var icon: TextureRect = TextureRect.new()
	icon.texture = Assets.tex("icon_coin")
	icon.custom_minimum_size = Vector2(36, 36)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	hb.add_child(icon)
	hb.add_child(label(str(Save.coins), 30, Color(1, 0.9, 0.3), 6))
	return hb

## Builds: theme -> animated background -> centered VBox. Returns the VBox.
static func build_screen(root: Control, show_bird: bool = false) -> VBoxContainer:
	root.theme = theme()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg = ScenicBG.new()
	bg.show_bird = show_bird
	root.add_child(bg)
	var m: Dictionary = safe_margins()
	var margin: MarginContainer = MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_top", int(16 + m["top"]))
	margin.add_theme_constant_override("margin_bottom", int(16 + m["bottom"]))
	margin.add_theme_constant_override("margin_left", int(16 + m["left"]))
	margin.add_theme_constant_override("margin_right", int(16 + m["right"]))
	root.add_child(margin)
	var center: CenterContainer = CenterContainer.new()
	margin.add_child(center)
	var vb: VBoxContainer = VBoxContainer.new()
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_theme_constant_override("separation", 12)
	center.add_child(vb)
	return vb

static func clear(box: Node) -> void:
	for c in box.get_children():
		box.remove_child(c)
		c.queue_free()
